# Reauditoria defensiva estática — delta de tooling (DV2-02, DV2-03 e DV2-05)

## 1. Veredito limitado ao escopo

Esta revisão não aprova o release completo.

| Achado anterior | Estado nesta revisão | Conclusão limitada |
|---|---|---|
| DV2-02 | **DESCONHECIDO para fechamento do gate; correção estática presente** | O delta elimina, de forma coerente, a transação pendente do teste e acrescenta uma regressão para o sintoma. Porém o critério do achado é o CI de `main` no novo commit. O sucesso desse run e o estado da tag pertencem às verificações ao vivo do parent e não foram presumidos. |
| DV2-03 | **CORRIGIDO no código, com execução fria pendente do parent** | O bootstrap novo inclui os pré-requisitos antes ausentes, na ordem necessária, e falha fechado. Não executei o script nem uma suíte. |
| DV2-05 | **CORRIGIDO no código, com regressões positivas pendentes do parent** | A leitura passa a ter teto de 8 MiB e a resposta precisa correlacionar versão, ID e exclusividade `result`/`error`. Timeout, retries, orçamento lógico e privacidade de erros permanecem como antes. Não executei os testes. |

Não identifiquei regressão bloqueadora nova no delta atribuído. Permanecem pendentes os checks dinâmicos do parent e os limites de modelo descritos nas seções 4–7.

## 2. Identidade e método

Identidade Git verificada diretamente no checkout canônico:

- raiz: `[WORKSPACE]`;
- `HEAD`: `559c509ff71d71e49ac720bd6acd8a9783531ebb`;
- árvore: `e5ed5db6404ae9d5464028690f788ea3a217ebbd`;
- baseline comparado: `5e63d2dba9123fdc585f7f272b83532b491fbc51`;
- checkout detached e `git status --porcelain=v1 --untracked-files=all` vazio no início;
- tag auditada local: objeto anotado `ca9aede4ab55de02db39d8714f60abf620515cfb`, apontando para `5e63d2dba9123fdc585f7f272b83532b491fbc51`;
- nenhuma tag local `v2-audit-2026-10-04.2` foi observada. Isso não é afirmação sobre o estado remoto atual.

A revisão foi exclusivamente estática. Não rodei testes, builds, bootstrap, Anvil, mutações, deploy, chamada RPC externa ou transação. Não alterei a árvore canônica. Inspecionei os diffs relevantes completos e o contexto ao redor em código, testes, CI, documentação, manifesto e evidência anterior.

O `freeze.json` fornecido é explicitamente `stage: pre-tag`, com `tag: null` e o run de `main` ainda `in_progress` no momento do empacotamento (`package/freeze.json:2-25`). Portanto, sucesso do CI principal e corte da tag são pendências do parent, não fatos desta revisão.

## 3. Separação entre alegações e fatos

### 3.1 Alegações fornecidas pelo pacote

O pacote afirma, entre outros pontos:

- causa raiz de DV2-02 como transação pendente de Anvil sobrevivendo ao isolamento e consumindo o nonce (`package/REMEDIATION.md:71-84`);
- 54/54 no comando do job Backend e reprodução dos três erros ao remover o drop (`package/REMEDIATION.md:80-84`);
- bootstrap bem-sucedido em checkout frio e `AutoExitInvariants` 10/10 (`package/REMEDIATION.md:86-96`);
- cobertura positiva do transporte RPC (`package/REMEDIATION.md:127-147`).

Essas execuções não foram repetidas aqui. O pacote entregue não contém logs do run frio do candidato nem logs da alegada reprodução por remoção do drop; `remediation/main-ci.json` registra o run do commit auditado e uma descrição da causa, não uma captura independente da pool do Anvil (`package/remediation/main-ci.json:13-18`).

### 3.2 Fatos confirmados em fonte e evidência registrada

- O delta real entre os dois commits contém as alterações atribuídas em `deploy.mjs`, `deploy.test.mjs`, `deploy-preflight.test.mjs` e o novo `audit-bootstrap.sh`.
- O log original registra que o teste de nonce passou e o teste imediatamente seguinte falhou com `nonce too low`; os dois seguintes viram `deployer_nonce_mismatch` (`DOMINO_V2_AUDIT_EVIDENCE.zip!evidence/ci-failed-job-111449829937.log:6352-6360,6417-6465`).
- No baseline, o teste de nonce desabilitava automine, criava a transação pendente, reabilitava automine e só depois o `isolated()` executava `evm_revert` (`5e63d2d:scripts/v2/deploy-preflight.test.mjs:158-170`).
- A auditoria anterior não confirmou a causa: seu probe de snapshot registrou 100 tentativas e zero falhas, e o relatório declarou a causa remota não confirmada (`reports/v2-audit-2026-10-04/AUDITORIA_DOMINO_V2.md:92-104,163-173`).
- O candidato remove a transação específica antes de reabilitar automine, faz drop global antes do revert e testa os nonces `latest` e `pending` após reabilitar automine e minerar (`scripts/v2/deploy-preflight.test.mjs:33-39,164-195`).
- A evidência anterior do cold start demonstra exatamente a falta de artefato que originou DV2-03: `vm.getCode: no matching artifact found`, com zero teste comportamental executado (`DOMINO_V2_AUDIT_EVIDENCE.zip!evidence/cold-instructions/official-example-suite.log:1-22`; relatório anterior em `reports/v2-audit-2026-10-04/AUDITORIA_DOMINO_V2.md:106-114`).
- A evidência anterior de DV2-05 registrava aceitação de versão/ID incorretos e de uma resposta de 2 MiB; isso era evidência do baseline, não do candidato (`DOMINO_V2_AUDIT_EVIDENCE.zip!evidence/deploy-probes-results.json`).

### 3.3 Verificações pendentes exclusivamente do parent

- executar as regressões positivas já versionadas, inclusive o comando dos cinco arquivos de tooling;
- executar o bootstrap em checkout realmente frio e ao menos a suíte de exemplo;
- conferir o run completo de `main` cujo `head_sha` seja exatamente `559c509ff71d71e49ac720bd6acd8a9783531ebb`;
- conferir eventual tag anotada e o freeze pós-tag sem inferi-los do PR ou do pacote pre-tag.

## 4. DV2-02 — isolamento de testes e transações pendentes

### 4.1 Correção estática

O helper compartilhado agora executa `anvil_dropAllTransactions` antes de `evm_revert` em toda região isolada (`scripts/v2/deploy-preflight.test.mjs:33-39`). A ordem é a defensiva correta para a reconstrução proposta: evita que uma transação retirada do estado revertido permaneça/reapareça na pool e seja minerada depois.

O teste que cria deliberadamente uma transação pendente também guarda o hash, chama `anvil_dropTransaction` antes de `evm_setAutomine(true)` e deixa o drop global como segunda barreira (`scripts/v2/deploy-preflight.test.mjs:164-181`). Isso remove a janela específica presente no baseline.

A regressão nova:

1. registra o nonce confirmado;
2. entra em `isolated()`;
3. desabilita automine e envia uma transação do deployer;
4. sai deixando-a pendente para o cleanup;
5. reabilita automine, minera um bloco;
6. exige que os nonces `latest` e `pending` permaneçam iguais ao original (`scripts/v2/deploy-preflight.test.mjs:184-195`).

Ela cobre o efeito relevante para o defeito: a transação daquele deployer não pode avançar o nonce do teste seguinte. Não inspeciona toda a txpool nem transações de outras contas, mas isso não é necessário para o sintoma registrado.

### 4.2 O que os logs provam — e o que não provam

O log de CI prova contaminação temporal compatível com nonce consumido entre testes: o teste que produz o pendente passa; o seguinte recebe `nonce too low`; depois o estado passa a produzir `deployer_nonce_mismatch`. O código antigo mostra uma origem concreta e imediatamente anterior para essa contaminação.

O log não captura a txpool no instante da falha e não identifica unicamente o mecanismo interno do Anvil. Além disso, o probe anterior de 100 iterações não reproduziu a falha. Assim, “`evm_revert` não limpa a pool e a transação foi minerada” deve ser tratado como **reconstrução de causa fortemente corroborada**, não como fato diretamente observado no run falho.

O delta é adequado para essa classe de interferência, independentemente de a corrida exata ocorrer em toda máquina. O fechamento de DV2-02, porém, continua desconhecido até o parent confirmar o run completo de `main` no candidato. A passagem posterior apenas do job falho no commit antigo, registrada em `package/remediation/main-ci.json:20-32`, não substitui esse gate.

### 4.3 Hardening não bloqueador

O cleanup coloca `dropAll` e `revert` no mesmo `finally`; uma falha do primeiro impediria o segundo e poderia mascarar a exceção original. Isso já faria a suíte falhar, não passar falsamente. Um `try/finally` aninhado para sempre tentar o revert seria endurecimento de diagnóstico, não critério aberto de DV2-02.

## 5. DV2-03 — bootstrap frio, ordem e fail-closed

O novo script é executável e usa `set -eu` antes de qualquer ação (`scripts/v2/audit-bootstrap.sh:1-20`). A sequência está correta:

1. instala as dependências de root e `app/` pelos lockfiles (`scripts/v2/audit-bootstrap.sh:22-23`); isso cobre Forge/solc no root e `viem` carregado via `app/package.json` por `deploy.mjs` (`scripts/v2/deploy.mjs:91-96,177-203`);
2. constrói os sete artefatos V1 que o size gate enumera (`scripts/v2/audit-bootstrap.sh:25-28`; conjunto completo em `scripts/check-contract-size.mjs:9-21`);
3. constrói as entradas V2 e `IntegrationArtifacts.sol` antes de qualquer suíte (`scripts/v2/audit-bootstrap.sh:29-34`), alinhado ao setup do CI (`.github/workflows/ci.yml:462-471`);
4. executa a checagem do manifesto contra o compile independente e contra `contracts/out` (`scripts/v2/audit-bootstrap.sh:35-37`; comportamento de recusa em `scripts/v2/release-manifest.mjs:59-78`);
5. imprime a mensagem de sucesso somente depois de todos os passos (`scripts/v2/audit-bootstrap.sh:37-38`).

O runner só executa o size gate depois de uma suíte bem-sucedida, e transforma artefato ausente ou gate reprovado em status não zero (`scripts/test-contracts.mjs:42-75`). O size gate enumera exatamente sete contratos e marca artefato ausente como falha (`scripts/check-contract-size.mjs:9-21,141-159`). `IntegrationArtifacts.sol` documenta que seus helpers concretos são carregados por `vm.getCode` e precisam de build prévio (`contracts/test/v2/integration/IntegrationArtifacts.sol:12-16,245-326`).

O script é fail-closed no caminho revisado: qualquer `npm ci`, build ou manifest check não zero interrompe a execução; não há fallback que converta ausência em sucesso. A ordem preserva os artefatos V1 antes da execução futura de uma suíte e gera os artefatos de integração antes do manifesto final.

Estado: correção estática completa. A alegação de execução fria bem-sucedida do candidato continua sendo alegação fornecida; o parent precisa exercê-la.

## 6. DV2-05 — transporte RPC

### 6.1 Limite de tamanho

`RPC_REPLY_MAX_BYTES` vale `8 * 1024 * 1024` (`scripts/v2/deploy.mjs:432-433`). `boundedReply` consome o stream por chunks, soma bytes e aborta antes de guardar o chunk que ultrapassa o teto (`scripts/v2/deploy.mjs:435-445`). `makeRpc` aplica esse leitor a toda resposta HTTP bem-sucedida que não seja 429 e converte a violação para `rpc_reply_too_large: <method>` sem corpo ou URL (`scripts/v2/deploy.mjs:460-479`). Respostas HTTP 429 têm o corpo cancelado sem leitura (`scripts/v2/deploy.mjs:470-472`).

O teste usa o mesmo caminho com teto reduzido para comprovar a borda e, separadamente, fixa a constante de 8 MiB (`scripts/v2/deploy.test.mjs:409-453`). Ele não aloca uma resposta real de 8 MiB + 1; isso é uma lacuna pequena de cobertura do valor default, não uma rota diferente na implementação.

### 6.2 Correlação e envelope

`validReply` exige objeto não-array, `jsonrpc === "2.0"`, exatamente uma propriedade própria entre `result` e `error`, ID exato para resultados e ID exato ou `null` apenas para erros (`scripts/v2/deploy.mjs:447-455`). O ID é capturado por tentativa, inclusive em retries (`scripts/v2/deploy.mjs:462-469`). JSON inválido e envelope inválido têm erro tipado e não são repetidos como rate limit (`scripts/v2/deploy.mjs:476-482`).

O delta de teste cobre ID errado, versão ausente/1.0, ambos/nenhum `result`/`error`, array/batch, resultado com ID nulo, JSON inválido e erro com ID nulo (`scripts/v2/deploy.test.mjs:424-452`). Em todos os casos de envelope inválido há uma única requisição, o que também confirma ausência de retry indevido (`scripts/v2/deploy.test.mjs:446-450`).

Limite de hardening não bloqueador: o objeto `error` só é testado como não nulo e `typeof === "object"`; arrays e objetos sem `code` inteiro/`message` string chegam a `rpc_method_failed`. Isso falha fechado — nenhum `result` é aceito — mas uma validação integral do objeto de erro JSON-RPC poderia ser mais estrita.

### 6.3 Timeout, retries e orçamento

Esses controles não foram alterados pelo delta:

- timeout: 60 s por tentativa via `AbortSignal.timeout(60000)` (`scripts/v2/deploy.mjs:468-469`);
- retries: somente HTTP 429 ou erros RPC reconhecidos como rate limit; cinco delays `[1,2,4,8,8]` s, portanto até seis tentativas e 23 s de backoff (`scripts/v2/deploy.mjs:425,457-482`);
- read-only: allowlist explícita antes da rede (`scripts/v2/deploy.mjs:487-497`);
- orçamento padrão: 2.000 chamadas lógicas e 900 s, verificados antes de iniciar cada chamada (`scripts/v2/deploy.mjs:490-498`);
- todos os comandos públicos que usam RPC passam por `endpoint()`/`readOnlyRpc` (`scripts/v2/deploy.mjs:965-968,994-1027`).

Limite de modelo já existente: retries internos contam como uma única chamada lógica, logo 2.000 chamadas podem gerar até 12.000 tentativas HTTP; o deadline de 900 s é conferido antes da chamada e não cancela uma chamada já iniciada. Uma chamada com cinco respostas de rate limit quase no timeout e uma tentativa final pode ocupar até aproximadamente 383 s. Isso não reabre DV2-05, cujo pedido era preservar esses limites, mas a documentação deveria chamá-los de orçamento lógico/de admissão, não teto absoluto de requests ou wall clock.

### 6.4 Privacidade de erros

Falhas de transporte, parse, envelope e tamanho são reduzidas a código + método, sem URL nem corpo (`scripts/v2/deploy.mjs:473-482`). Em endpoint não-loopback, a mensagem RPC remota é sempre omitida. Em loopback, no máximo 200 caracteres são incluídos e substrings URL HTTP(S) são substituídas por `[endpoint]` (`scripts/v2/deploy.mjs:425-430`). Os testes fixam a omissão remota e a sanitização local (`scripts/v2/deploy.test.mjs:460-464`).

Limite de privacidade não bloqueador: a classificação “local” usa apenas o hostname do endpoint. Um proxy/túnel em loopback é tratado como local, e texto sensível que não esteja no formato de URL pode aparecer nos 200 caracteres. O comportamento é preexistente e não faz parte da lacuna de correlação/tamanho corrigida, mas suprimir toda mensagem de provider também em loopback seria mais conservador.

## 7. Evidência, integridade e cobertura

O `SHA256SUMS` do pacote enumera 12 membros; todos os 12 hashes calculados coincidiram. Entre eles:

- `REMEDIATION.md`: `bd91c4d4e17f237f288029589fee9856a1547edbc13457b50756eea79f809e6e`;
- `V2_AUDIT_PACKAGE.md`: `bc3aba68c4d07135d74508d67a34527abf03df1a1b655b7567ff590d60bcc008`;
- `freeze.json`: `ad30df9869a30d5b5608011dcc01f691039c2ea14d11e9aef9c51adb902e7bdc`;
- `manifest-delta.json`: `7a4c076e5a73af123b101540c47070e847219deb4a3a3599186eb073968afbd2`;
- `release-artifacts-v2.json`: `2975c377c6f3690a702fddeecfe4ffb2c4ccab6e52c8739f4877ce458f66ed5c`;
- `remediation/main-ci.json`: `8a0c566ff3c7700098678974c68e2dd0ec5c21227bfd96e4a22af8942281a75d`;
- `v2-remediation.patch`: `8691516efb303420b79bfbcc9106cf023db861cd617d01cb556dc6474d9491f6`.

A lista completa dos 12 membros, tamanhos e hashes está em `result.json`; não foi reduzida a um campo de sucesso.

A evidência anterior tem SHA-256 externo `db3a30d7b6cdb8ab8734f160ff1a8a5db5aeab6ed186c577f7ef7ff93976650e`. Seu ZIP tem 131 membros: `MANIFEST.json` mais 130 payloads. Comparei o conjunto completo, tamanho e SHA-256 de todos os 130 payloads com o manifesto interno: zero membro ausente, extra ou divergente. O SHA-256 de `MANIFEST.json` é `0ff884a629ebda5841840acf00d89d62fc8845a1d7bef81b83512f0946cac72a`.

Os arquivos centrais do candidato também foram ligados por hash no `result.json`. O manifesto de release contém `scripts/v2/deploy.mjs = feae2e8725659662de0fa6b53b1283c9d0363965a7ba3204f9a3738d1b13cea5` (`contracts/release-artifacts-v2.json:81-87`), igual ao arquivo revisado.

Relatórios de mutação estão fora do escopo atribuído e não foram avaliados semanticamente. Seus membros continuam presentes no conjunto completo e hashado do pacote; nenhum “success” de mutação foi usado para fechar DV2-02/03/05.

## 8. Desconhecidos e limites finais

- O run completo de `main` no commit candidato não foi consultado nem presumido.
- A tag `.2` e seu eventual objeto anotado/freeze pós-tag não foram consultados remotamente nem presumidos.
- Nenhuma regressão positiva foi executada nesta revisão estática.
- O bootstrap do candidato não foi exercitado em checkout frio por este revisor.
- A causa de DV2-02 é fortemente corroborada, mas não diretamente provada por inspeção da txpool no run falho.
- O endpoint RPC continua sendo uma fonte de dados não confiável; validar envelope e tamanho não prova veracidade on-chain.
- Esta conclusão não cobre DV2-01, DV2-04 nem o restante do release e não substitui a decisão consolidada do parent.
