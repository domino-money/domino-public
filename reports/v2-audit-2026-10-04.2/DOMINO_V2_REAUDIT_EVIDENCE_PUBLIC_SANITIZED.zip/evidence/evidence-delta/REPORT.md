# Reauditoria defensiva estática — DV2-04 e limites documentais

## Veredito

**DV2-04: ABERTO, com remediação parcial substancial.**

O candidato corrige estaticamente duas partes materiais do achado: agora há batches versionados e aplicáveis para as campanhas de 29, 18 e 5 mutações, e as oito substituições stale do vault foram reescritas, com duas guardas novas incluídas. O runner também passa a falhar fechado nos casos relevantes e os quatro relatórios atuais são internamente consistentes com este tree.

A lacuna histórica literal, porém, não foi fechada: os scripts originais ficaram fora do repositório e os trees efetivamente executados não foram hashados. `mutation-history.json` registra isso expressamente. Os batches atuais são transcrições posteriores e os relatórios atuais são reruns declarados pelos autores, não replay independente dos runs históricos. A revisão estática não executou mutações, testes ou builds; portanto, os resultados de execução atuais permanecem **desconhecidos nesta revisão, pendentes do replay do parent**.

Este resultado é de garantia/proveniência de evidência, não uma vulnerabilidade de contrato demonstrada, e não constitui aprovação global de release.

## 1. Escopo e método

- Fonte canônica: `[WORKSPACE]`.
- Identidade verificada: commit `559c509ff71d71e49ac720bd6acd8a9783531ebb`, tree `e5ed5db6404ae9d5464028690f788ea3a217ebbd`, checkout detached e limpo no início da revisão.
- Base comparada: commit `5e63d2dba9123fdc585f7f272b83532b491fbc51`, tree `db8bfb4e57a043a94f7fe55bf02725cb65836b1c`.
- Tag anterior verificada: objeto anotado `ca9aede4ab55de02db39d8714f60abf620515cfb`, apontando para o commit anterior.
- O `package/freeze.json:7-10` identifica corretamente o candidato como pré-tag; `package/freeze.json:20-25` registra o main ainda `in_progress` no momento de produção do pacote.
- Foram inspecionados o diff completo relevante e o código circundante do runner, testes unitários do runner, 13 batches, quatro relatórios de rerun, histórico, manifesto, documentação e regressões citadas.
- Foram feitas apenas leituras, hashes SHA-256, comparação de conjuntos/labels e contagem textual. Nenhum teste, build, mutação, PoC ou contrato foi executado.

Distinção usada abaixo:

- **Alegação fornecida:** texto ou resultado registrado pelo autor no pacote/repositório.
- **Confirmado estaticamente:** relação verificável por leitura/hash/cálculo sem executar testes.
- **Pendente do parent:** comportamento de execução que esta revisão foi proibida de reproduzir.

## 2. Achado residual de proveniência

### DV2-04-P1 — a campanha histórica exata continua não reproduzível

Severidade: baixa, garantia/proveniência.

O achado anterior pediu “inputs e resultados exatos das campanhas históricas, vinculados ao source hash” (`reports/v2-audit-2026-10-04/AUDITORIA_DOMINO_V2.md:116-124`). O material novo melhora a situação, mas preserva a limitação central:

- `reports/v2-audit-2026-10-04/remediation/mutation-history.json:3` afirma que os scripts antigos estavam fora do repositório e não hashavam a fonte.
- As referências de tree são aproximações posteriores: working trees “committed five minutes after”, “committed as” e “committed ten minutes after”, sem hash no instante do run (`mutation-history.json:9`, `:238`, `:447`).
- Os identificadores abreviados `c7290aaa`, `566e91d3` e `eeb4c6c8` não resolvem para objetos neste checkout completo. Mesmo que fossem recuperados externamente, o próprio histórico diz que o run ocorreu antes do commit e em working tree não hashado.
- Os conjuntos e a ordem de labels históricos coincidem exatamente com os batches atuais: 29/29, 18/18 e os cinco D-1/D-2. Isso confirma a correspondência nominal, não a identidade dos textos antigos, suites, artefatos ou trees executados.
- Os reports atuais prendem batch, fontes e suites por SHA-256, mas o schema não prende commit/tree, SHA do próprio runner, `test-contracts.mjs`, toolchain, artefatos usados/reconstruídos, instante do run ou estatísticas dos baselines (`scripts/mutate-contracts.mjs:245-260`). Logo, sua consistência é verificável; sua execução não é autenticada pelo próprio report.

Conclusão precisa: **a reprodutibilidade do candidato atual foi remediada estaticamente; a proveniência exata dos runs históricos continua aberta e não pode ser retroativamente reconstruída com o material entregue.**

## 3. Runner de mutações

### 3.1 Propriedades confirmadas estaticamente

Não foi encontrado defeito material fail-open no fluxo revisado:

- O parser exige summaries por suite e o total agregado, rejeita zero testes executados, inconsistência entre `ok/FAILED` e falhas, terminação por sinal/erro, status incompatível e saída incompleta como `NO BUILD` (`scripts/mutate-contracts.mjs:53-54`, `:79-102`).
- Em múltiplas suites, qualquer `NO BUILD` invalida o mutante; só depois qualquer falha conta como `CAUGHT` (`scripts/mutate-contracts.mjs:122-128`).
- Texto ausente ou repetido sem índice, índice inválido, edição vazia ou idêntica não aplica (`scripts/mutate-contracts.mjs:131-142`).
- Labels devem ser únicas; paths são relativos e confinados; survivors esperados aceitam apenas `NOT CAUGHT` com razão não vazia (`scripts/mutate-contracts.mjs:144-169`).
- `NO BUILD`, `NOT APPLIED`, verdict desconhecido, ausência de rows e divergência do esperado produzem exit code 1 (`scripts/mutate-contracts.mjs:172-175`).
- O rebuild ocorre antes dos baselines e depois de cada edição aplicável; falha de rebuild encerra o baseline ou marca o mutante `NO BUILD` (`scripts/mutate-contracts.mjs:188-223`).
- Cada suite distinta tem baseline pristine e qualquer baseline diferente de `NOT CAUGHT` interrompe o batch antes dos mutantes (`scripts/mutate-contracts.mjs:195-207`).
- As fontes são restauradas entre mutantes e no fim (`scripts/mutate-contracts.mjs:211-229`).
- `--only` recusa label desconhecida e preserva a ordem do batch (`scripts/mutate-contracts.mjs:236-243`).
- O report inclui SHA-256 do batch e mapas completos das fontes e suites selecionadas, além de `rebuild`, seleção, rows, baseline, summary e exit code (`scripts/mutate-contracts.mjs:245-260`).

Os testes unitários existentes cobrem estaticamente esses ramos: parser incompleto (`scripts/mutate-contracts.test.mjs:32-60`), exits fail-closed (`:74-82`), restauração e baseline (`:84-115`), rebuild (`:137-170`), múltiplas suites (`:173-205`), hashes do report (`:208-224`) e seleção (`:227-232`). **A presença desses testes foi confirmada; sua passagem não foi verificada aqui.**

### 3.2 Limites do harness/evidência

- O report não contém identidade do runner/toolchain/artefatos nem commit/tree. Isso não muda o verdict de um run real, mas limita a proveniência independente do JSON arquivado.
- Os baselines são executados pelo código, mas o report persiste apenas `baselineFailure: null`, não os resultados completos de cada baseline. Os detalhes fornecidos são, portanto, alegações de execução não reconstituíveis só pelo JSON.
- Não foi encontrado erro estático que permitisse a um `NOT APPLIED`, `NO BUILD`, timeout/sinal ou summary parcial contar como `CAUGHT`.

## 4. Batches versionados e aplicabilidade no candidato

Cálculo textual não executante sobre os 13 batches: **823 mutações**, seis survivors explicitamente esperados; zero labels duplicadas, zero fontes/suites ausentes e zero substituições não aplicáveis ao tree atual. “Aplicável” aqui significa apenas que o texto `old` ocorre exatamente uma vez, ou que o índice explícito existe; não significa que o mutante compilou ou foi detectado.

| Batch | SHA-256 | Mutações | Fontes | Suites | Rebuild | Survivors | Não aplicáveis |
|---|---|---:|---:|---:|---|---:|---:|
| `auto-exit-2026-10-01.json` | `dec069da7c4de0b3e04e809fa82884055b416ef49657afd3e2ff38e041077b5a` | 107 | 1 | 3 | — | 1 | 0 |
| `security-guards-2026-09-21.json` | `a45d2b1353863f9ceacbe68703f261a2c6ad918c4878511a03b8aeb52b527821` | 4 | 3 | 3 | — | 0 | 0 |
| `setup-recovery-2026-09-21.json` | `2b4cdf061870b37719c541f0b4ec114b930eb9bc1d86ac77ad4f70dd6bbcb966` | 4 | 1 | 1 | — | 0 | 0 |
| `v2-audit-2026-10-04.json` | `765ddc0bf42da56600224e92d3e208eb9e4ce0aaf402a835c7dbcc02bc42b82d` | 10 | 3 | 4 | — | 0 | 0 |
| `v2-auto-exit-adversarial-2026-10-03.json` | `a6e667daec3c02abde9036089cfb8a66092c55d6048ade39b08ef14849a0e2a1` | 29 | 1 | 3 | `DominoAutoExit.sol` | 0 | 0 |
| `v2-f1-registry-anchor-2026-10-01.json` | `b2c77ae53b00470beb02e187e464955fe20e5ebbc2a5ecea5087a20c69f96c64` | 96 | 3 | 3 | — | 0 | 0 |
| `v2-fees-route-2026-10-01.json` | `a9ad35726e0d19e167d55b2c1c97a420c3cf35c1df003d655c676fc33388c4c4` | 117 | 7 | 8 | — | 0 | 0 |
| `v2-integration-2026-10-02.json` | `b099114e0c7337217ad4fae5be819e71d577dde71b3f3727868bf7b95b0c31f5` | 58 | 8 | 6 | — | 0 | 0 |
| `v2-positions-2026-10-01.json` | `f94556b3090c51ef0011329ae32ee7104575c0d92ecb9233f46817ed1a951f8a` | 86 | 3 | 3 | — | 2 | 0 |
| `v2-registry-adversarial-2026-10-03.json` | `09071b92e8927216a398bc65450d0106cf99f4328c51dace918d1507cb339e12` | 18 | 1 | 1 | `DominoRegistry.sol` | 0 | 0 |
| `v2-return-reserves-2026-10-02.json` | `88b5965c97b99b2d293f0ee8995bb70ffdec33eefaa98a6f06b549cffbfe9c8c` | 24 | 3 | 1 | — | 0 | 0 |
| `v2-vault-2026-10-02.json` | `c3c3707fe421d5b84c88f852b3e1b68501db51f1e8b70c6ceee8ac5d7b3a482e` | 194 | 8 | 9 | — | 2 | 0 |
| `v2-zap-2026-10-02.json` | `90ee2f835493075d974706a3a2728ba0dff0da7b9200a838179459ef24793a8d` | 76 | 4 | 3 | — | 1 | 0 |

Os dois batches cujas suites carregam contratos via artefato declaram rebuild explícito: auto-exit em `contracts/mutations/v2-auto-exit-adversarial-2026-10-03.json:4-7` e registry em `contracts/mutations/v2-registry-adversarial-2026-10-03.json:4-8`.

## 5. Relatórios atuais do candidato

Os quatro reports do repositório são byte a byte iguais às cópias do pacote. Em todos:

- SHA do batch confere;
- conjunto completo e SHA de cada fonte conferem com o tree e com `contracts/release-artifacts-v2.json`;
- conjunto completo e SHA de cada suite conferem com o tree;
- `rebuild` confere com o batch;
- labels/ordem/seleção conferem com o batch;
- contagens, expectativas, summary, `baselineFailure: null` e exit code 0 são internamente consistentes.

| Report | SHA-256 | Seleção | Rows declaradas | Resultado declarado |
|---|---|---|---:|---|
| `v2-audit-2026-10-04.json` | `8b655aa99a84d8ef8ba005ca49bbc9927d0764f003dfbcd464a19c2fdcdd8387` | batch inteiro | 10 | 10 `CAUGHT` |
| `v2-auto-exit-adversarial-2026-10-03.json` | `42bc3d6044980e685410fed2703e43156cd8feac73d7dcc42253bf375e3eb584` | batch inteiro | 29 | 29 `CAUGHT` |
| `v2-registry-adversarial-2026-10-03.json` | `91bb08eb57e059b3fff8d97ab2a851f79762b17fa3085b9e8e90488c1dc4fbdf` | batch inteiro | 18 | 18 `CAUGHT` |
| `v2-vault-2026-10-02.rewritten.json` | `a329dd7ce1e2bca11fab64b2ed3fad8125cdf3c5010832f9f02f4db37e20a000` | 10 labels explícitas | 10 | 10 `CAUGHT` |

Os mapas completos de fontes/suites, seus hashes e todos os labels selecionados estão em `result.json`; não foram reduzidos a um booleano de sucesso.

Importante: `CAUGHT`, baseline limpo e exit code são **alegações fornecidas pelos JSONs**. Esta revisão confirmou sua coerência, mas não os reproduziu.

## 6. Reescrita das entradas stale do vault

Confirmado pelo diff entre os dois commits:

- Batch anterior: 192 labels; atual: 194.
- Cinco labels tiveram a substituição reescrita sem mudar o nome: `withdrawal needs an amount`, `withdrawal needs the reserves`, `exitAll pauses`, `policy: overlap cap`, `limits: an observation age`.
- Três labels stale foram substituídas por nomes que descrevem os caps atuais:
  - `policy: an interval` → `policy: the 600 s interval floor`;
  - `limits: slippage below 100%` → `limits: the 10% slippage cap`;
  - `limits: band below 100%` → `limits: the 5% band cap`.
- Duas guardas novas foram adicionadas: `limits: the 300 s observation age cap` e `withdrawal needs a recipient`.
- As dez labels selecionadas estão completas em `reports/v2-audit-2026-10-04/remediation/mutations/v2-vault-2026-10-02.rewritten.json:12-23`; as dez rows aparecem em `:24-84`.
- Todas as 194 substituições atuais aplicam textualmente. As oito antigas que o audit marcou stale foram confirmadas no artefato anterior de evidência como zero ocorrências; o estado atual não as conta silenciosamente.

Essa parcela do DV2-04 está **corrigida estaticamente**.

## 7. Limites documentais solicitados

### B — double-entry

**Clarificação adequada e confirmada no modelo do código.** `DominoAutoExit` mantém créditos `unclaimed` por owner e endereço do token (`contracts/src/v2/autoexit/DominoAutoExit.sol:59-62`), limpa/paga esses créditos em `:193-199` e acumula entrega diferida em `:440-446`. A documentação agora diz explicitamente que tudo mantido por endereço nessa moeda, inclusive `unclaimed`, está exposto ao alias econômico (`docs/v2/F4_AUTO_EXIT.md:215`). Isso atende a correção pedida em `AUDITORIA_DOMINO_V2.md:144`. É limite aceito, não demonstração sobre token suportado.

### Rearm V3

**Clarificação adequada e coerente com a implementação.** A checagem compara apenas checkpoints, exige aumento de liquidez e limita `tokensOwed` entre os produtos de fee growth pela liquidez anterior e atual (`contracts/src/v2/vault/DominoV2VaultV3.sol:71-92`, `:165-173`). Portanto, não observa a sequência intermediária; principal de uma redução que caiba nessa faixa pode parecer fee. A redação retira “dust”, explicita que não há teto absoluto pequeno e dá o bound em função de fee growth e delta de liquidez (`docs/v2/F3_VAULT.md:106-115`; `reports/V2_AUDIT_PACKAGE.md:236`). Os testes fonte incluem o caso de add seguido de redução e os casos de collect/checkpoint (`contracts/test/v2/vault/DominoV2VaultCustody.t.sol:367-435`), mas não foram executados aqui.

### Gas de `exitAll`

**Clarificação de modelo/runbook adequada; números de benchmark permanecem alegações de execução.** O loop é linear no número de membros (`contracts/src/v2/vault/DominoV2VaultBase.sol:294-318`). O documento declara que não há certificado de capacidade e fixa o runbook: pause, desabilite módulo, retire filhos um a um e retire reservas (`docs/v2/F3_VAULT.md:256-268`; `reports/V2_AUDIT_PACKAGE.md:237`). A regressão fonte usa cap `16,777,216`, tenta `exitAll`, varre orçamento em passos de 4M e exercita `withdrawChild` com 500k e `pause` com 200k (`contracts/test/v2/adversarial/ReturnBomb.t.sol:10-14`, `:101-134`).

A revisão estática confirma o cenário e os budgets codificados, mas não confirma a observação “28–32M” nem a passagem dos calls; isso depende do run pendente do parent. A estimativa de aproximadamente 216 membros também é apresentada documentalmente, não como certificado universal.

### Contagem de linhas

Confirmado por contagem não executante sobre os 52 membros do manifesto: 8.040 linhas no commit anterior e 8.062 neste candidato; todos terminam com newline. A correção documental em `reports/V2_AUDIT_PACKAGE.md:69-83` é consistente.

## 8. Integridade do pacote

Todos os 12 membros listados em `package/SHA256SUMS` conferem. Os membros completos e hashes estão em `result.json`. As oito cópias que têm contraparte direta no repositório — package, manifesto, main CI, histórico e quatro reports — são byte a byte idênticas.

Hashes dos componentes centrais do harness:

- `scripts/mutate-contracts.mjs`: `2112d09e7f7f572c2cf14bc4eafda61ca402e0788a016dd5923340d491c816ab`.
- `scripts/mutate-contracts.test.mjs`: `84c80c54f6556bfb761a8eaf9349e1998006e5da5bf9a0268671140cff024a4a`.
- `scripts/test-contracts.mjs`: `87a18f7a7a57e6aad5c59ffcff3a6292bff04d967148f99da500a5e4e8b059df`.

## 9. Pendências e limites desta conclusão

1. Parent: executar os testes unitários do runner e os quatro reruns de mutação no commit/tree exatos; comparar o output produzido com os reports arquivados.
2. Parent: executar as regressões positivas de B/rearm/ReturnBomb; esta revisão só confirmou sua presença e ligação estática.
3. Irrecuperável com o pacote atual: provar que os scripts, edits, suites, artifacts e working trees dos três runs históricos eram exatamente os agora transcritos.
4. Os reports atuais não autenticam runner/toolchain/artefatos; uma futura versão poderia incluir commit/tree, hashes dos runners, versão do toolchain, hashes de artefatos e resultados completos dos baselines.
5. Nenhuma conclusão aqui cobre módulos fora do escopo, estado de chain, configuração operacional ou aprovação integral de release.

## 10. Fechamento por requisito

| Requisito | Estado |
|---|---|
| Batches 29/18/5 versionados e aplicáveis | Confirmado estaticamente |
| Rebuild de auto-exit/registry | Confirmado estaticamente |
| Parser e exits fail-closed | Confirmado estaticamente; testes não executados |
| Reports atuais: hashes, membros, labels, contagens e seleção | Consistentes e completos |
| Oito entradas stale reescritas + duas novas | Confirmado estaticamente |
| Replay independente dos reports atuais | Pendente do parent |
| Proveniência exata das campanhas históricas | Aberta |
| B/rearm/gas documentados com os limites pedidos | Confirmado estaticamente; métricas de gas pendentes |
| Aprovação global de release | Não emitida |
