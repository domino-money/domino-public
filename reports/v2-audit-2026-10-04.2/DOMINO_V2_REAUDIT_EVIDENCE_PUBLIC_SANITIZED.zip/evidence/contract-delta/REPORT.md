# Reauditoria defensiva da remediação DV2-01

## Veredito limitado

DV2-01: **FIXED na revisão estática**, com fechamento condicionado à execução, pelo processo pai, das regressões já entregues.

A alteração de produção passa a incluir todos os tokens intermediários de caminhos V3 estruturalmente válidos no conjunto de saldos observado antes e depois de cada perna. Um intermediário que não seja a entrada ou a saída da perna deve terminar com o mesmo saldo; divergência resulta em `SwapEffectMismatch`. A revisão não encontrou regressão de contabilidade que reabra DV2-01.

Este veredito:

- cobre somente DV2-01 e o delta contratual atribuído;
- é estático: nenhum teste, build, mutação ou PoC foi executado nesta revisão;
- não é aprovação geral da release nem dos achados DV2-02 a DV2-05;
- não converte os resultados registrados no pacote em resultados desta revisão.

## Identidade canônica

Identidade observada diretamente no Git:

- raiz: `[WORKSPACE]`;
- commit: `559c509ff71d71e49ac720bd6acd8a9783531ebb`;
- tree: `e5ed5db6404ae9d5464028690f788ea3a217ebbd`;
- commit anterior revisado: `5e63d2dba9123fdc585f7f272b83532b491fbc51`, confirmado como ancestral;
- parent imediato: `84b16107c0bb53ee5984ba0a2a997539e2821cca`;
- estado canônico: limpo no início e novamente verificado ao final.

A identidade coincide com `package/REMEDIATION.md:5` e `package/freeze.json:7-8`. O `freeze.json` fornecido é explicitamente pré-tag (`stage: pre-tag`, tag nula) em `package/freeze.json:2-10`.

## Separação da evidência

### Alegações fornecidas, não reexecutadas aqui

O pacote afirma, entre outros pontos:

- CI do PR #323 concluído com sucesso e CI de `main` ainda em andamento na criação do pacote (`package/freeze.json:11-26`);
- regressões e campanhas de mutação aprovadas (`package/REMEDIATION.md:59-69` e `:116-125`);
- quatro artefatos contratuais alterados, cada um com acréscimo de 212 bytes, e ABI inalterada (`package/REMEDIATION.md:29-40`);
- V2 ainda não implantado em cadeia pública (`package/REMEDIATION.md:57`).

Nesta revisão, essas afirmações de execução permanecem **supplied claims**. A integridade dos arquivos do pacote foi confirmada contra todos os 12 membros de `package/SHA256SUMS`, mas isso não equivale a reproduzir CI, testes, compilação ou mutações.

### Fatos confirmados pela fonte e pelo Git

Foram confirmados sem executar código do projeto:

- entre os dois commits, há um único arquivo Solidity de produção alterado sob `contracts/src/v2`: `contracts/src/v2/route/DominoSwapExecutor.sol` (23 linhas adicionadas, uma removida);
- o delta funcional de produção é a ampliação do conjunto rastreado e a nova leitura de intermediários em `contracts/src/v2/route/DominoSwapExecutor.sol:425-464`;
- compilador, mapa de componentes e os 52 membros de `sources` são idênticos nos manifests anterior e atual; somente o hash de `DominoSwapExecutor.sol` muda;
- os 12 membros de `contracts` e os seis membros de `releaseInputs` permanecem os mesmos; no conjunto de inputs de release, somente `scripts/v2/deploy.mjs` muda, fora da análise DV2-01;
- os 12 hashes de ABI são idênticos entre os manifests;
- exatamente quatro bytecodes mudam: `DominoAutoExit`, `DominoV2VaultSwapModule`, `DominoZapV3` e `DominoZapV4`; os outros oito permanecem idênticos;
- o manifest do repositório é byte a byte idêntico ao manifest fornecido no pacote e tem SHA-256 `2975c377c6f3690a702fddeecfe4ffb2c4ccab6e52c8739f4877ce458f66ed5c`.

### Validação pendente exclusivamente do processo pai

Permanecem pendentes:

- execução das regressões de rota, zap, vault e auto-exit;
- reprodução das cinco mutações DV2-01;
- rebuild independente dos artefatos para derivar os hashes do manifest, em vez de apenas comparar os manifests versionados;
- qualquer conclusão sobre o estado final de CI/tag posterior ao `freeze.json` pré-tag fornecido.

## Análise do delta de produção

### Conjunto rastreado, capacidade e deduplicação

`_executeLegs` constrói uma única lista rastreada antes das pernas, captura os saldos e, após cada perna, aplica `_checkEffect` (`contracts/src/v2/route/DominoSwapExecutor.sol:133-153`). A checagem preservada exige:

- débito líquido exatamente igual a `amountIn` para `tokenIn` (`:414-415`);
- crédito mínimo de `minAmountOut` para `tokenOut` (`:416-418`);
- saldo idêntico para qualquer outro token rastreado (`:419-420`).

A nova alocação reserva `MAX_HOPS + 1`, isto é, cinco posições por perna, além de uma posição por item de `extra` (`:435`). Ela é suficiente:

- um caminho V3 com `H` hops contém `H + 1` posições de token;
- `H <= MAX_HOPS == 4` (`:75-76`, `:329-332`);
- depois de incluir entrada e saída, há no máximo `H - 1` intermediários;
- portanto uma perna V3 válida pode acrescentar no máximo cinco tokens distintos no total;
- caminhos estruturalmente inválidos não acrescentam intermediários e ainda consomem no máximo as duas extremidades já reservadas;
- os itens de `extra` têm capacidade dedicada;
- `_include` elimina duplicatas antes de incrementar `count` (`:466-471`).

Não foi encontrada possibilidade de escrita além da capacidade alocada nos limites atuais de pernas e hops.

### Indexação de todos os intermediários

`_includeHops` replica os três critérios estruturais de `_swapV3`: mínimo de 43 bytes, resto zero para blocos de 23 bytes e no máximo quatro hops (`contracts/src/v2/route/DominoSwapExecutor.sol:329-332` e `:452-455`). Para um caminho aceito estruturalmente, o laço percorre `h = 1` até `h = hops - 1` e lê o endereço no início de cada hop posterior (`:456-461`). Esses índices são exatamente as posições intermediárias; as extremidades já haviam sido inseridas em `:438-439`.

Com quatro hops, o laço percorre as três posições internas. A deduplicação é intencional: se uma posição interna reutiliza a entrada, a saída ou outro intermediário, o mesmo endereço permanece representado uma única vez.

### Comportamento de caminhos inválidos

Para comprimentos curtos, parciais ou acima do limite, `_includeHops` retorna sem ler endereços internos (`:453-455`). `_swapV3` rejeita depois com `InvalidPlan` antes de executar qualquer hop (`:326-332`). As regressões adicionadas exigem `InvalidPlan`, e não apenas qualquer erro, para um byte residual e para cinco hops por endereços sem código (`contracts/test/v2/route/DominoSwapExecutorV3.t.sol:246-277`). Isso demonstra a semântica pretendida para os três erros estruturais.

Limite de semântica: um caminho com comprimento estruturalmente válido, mas inválido por extremidade, pool ou comportamento do token, já pode ter seus intermediários consultados por `_balances` antes de `_runLeg`. Se um intermediário não responder a `balanceOf`, o fechamento é seguro e atômico, mas o seletor pode ser `TokenCallFailed` em vez de `InvalidPlan`. Isso não abre DV2-01; é consequência de exigir saldo observável do intermediário.

### Integração com a checagem de efeito

O token intermediário agora é capturado antes de qualquer perna (`:142-143`) e após cada perna (`:147-150`). Como ele não é, no caso original, `leg.tokenIn` nem `leg.tokenOut`, cai no ramo “outro token” de `_checkEffect` e deve permanecer idêntico (`:419-420`). Um débito adicional observável no saldo faz a chamada inteira reverter; a reversão também desfaz hops anteriores e alterações de estado dos hosts.

A implementação não tenta validar cada transferência isoladamente: ela preserva a garantia contábil por endereço ao fim de cada perna. Isso é coerente com o modelo pré-existente de efeito líquido do executor.

## Garantias pré-existentes por host

### Rota/harness

O harness executa `_executeLegs` dentro do lock compartilhado (`contracts/test/v2/route/V2RouteTestKit.sol:274-310`). O helper de recusa exige o seletor exato (`V2RouteTestKit.sol:40-50`), portanto as novas asserções não aceitam um erro arbitrário.

### Zap

`DominoZapBase` herda `DominoAssistedSwap` (`contracts/src/v2/zap/DominoZapBase.sol:70`), que chama `_executeLegs` e depois confirma que cada moeda de entrada continua cobrindo `owedFees` (`contracts/src/v2/route/DominoAssistedSwap.sol:24-42`). O conjunto do action já cobre moeda nativa, moedas do pool, inputs e outputs (`contracts/src/v2/zap/DominoZapBase.sol:363-385`); a remediação acrescenta o intermediário V3 que antes faltava. Disponibilidade e refund usam apenas `_unowedBalance`, preservando dívida de fee (`DominoZapBase.sol:395-416`; `contracts/src/v2/fees/DominoFeeLedger.sol:99-102`).

### Vault

`DominoV2VaultSwapModule` executa as pernas por `delegatecall` no saldo e storage do vault, com as duas moedas do pool em `extraTracked` (`contracts/src/v2/vault/DominoV2VaultSwapModule.sol:8-25`; `contracts/src/v2/vault/DominoV2VaultExecutor.sol:212-240`). O executor do vault debita o lote antes da rota, mede entrada e saída novamente e credita a saída ao mesmo source (`DominoV2VaultExecutor.sol:223-238`). O ledger expõe reservas como idle mais todos os lots (`contracts/src/v2/vault/DominoV2VaultBase.sol:95-104`), e `recoverToken` limita recuperação ao saldo não devido e não contabilizado (`DominoV2VaultBase.sol:269-277`). Assim, um hop doado/recoverable deve continuar fisicamente no vault; a nova checagem por efeito impõe isso.

### Auto-exit

O auto-exit mantém `owedFees` e créditos `unclaimed` por owner/token (`contracts/src/v2/autoexit/DominoAutoExit.sol:193-199`, `:439-458`). A conversão exige que todas as pernas vendam a moeda source para o alvo, consome exatamente todo o source e chama `_executeLegs` com as duas moedas do pool, além dos tokens de todas as pernas e dos novos intermediários V3 (`DominoAutoExit.sol:388-422`). Uma falha reverte também a marcação antecipada do mandato como executado (`:233-270`), preservando o mandato ativo.

## Por que Universal Router e V4 não precisam da mesma enumeração

A conclusão está confirmada no código e é limitada ao saldo do host:

- Universal Router: o host aprova somente `leg.tokenIn`, por `amountIn`, para Permit2 e para o router, e exige ambas as allowances zeradas após a chamada (`contracts/src/v2/route/DominoSwapExecutor.sol:270-291`). Tokens internos à rota do router não são transferidos a partir do host por essa interface.
- V4 direto: os hops acumulam deltas dentro do PoolManager (`DominoSwapExecutor.sol:230-255`); o host liquida somente `tokenIn` e recebe somente o `tokenOut` final (`:208-223`).

A remediação, portanto, está corretamente limitada a `LEG_V3_POOL` em `:440`.

## Revisão das regressões entregues

| Host | Asserções observadas | Avaliação estática |
|---|---|---|
| Rota | `DominoSwapExecutorV3.t.sol:285-295` exige `SwapEffectMismatch`, saldo intermediário e input intactos após revert, depois executa o mesmo caminho com token normal e preserva o holding. `:300-308` cobre intermediário posterior. `:246-277` exige `InvalidPlan` nos formatos inválidos. | Verifica seletor, obrigação protegida, atomicidade e caminho positivo; não é “qualquer erro”. |
| Zap | `HopTokenBacking.t.sol:200-210` exige falha e seletor `SwapEffectMismatch`, saldo físico exatamente igual ao fee devido e `owedFees` inalterado. | Verifica diretamente o passivo protegido e a razão da recusa. |
| Vault | `HostileOperator.t.sol:200-227` usa `expectRevert(SwapEffectMismatch)`, exige que o saldo recoverable do hop permaneça em `5e15` e chama `_ledgerBalanced`. | Verifica o holding fora do ledger; `_ledgerBalanced` cobre as moedas padrão, enquanto a asserção direta cobre o hop. O teste pré-existente em `:166-194` fornece o caminho de sucesso do host. |
| Auto-exit | `AutoExitAttacks.t.sol:755-783` cria crédito diferido real, exige `SwapEffectMismatch`, saldo igual ao crédito, `unclaimed` inalterado e mandato ainda ativo. O helper exige o seletor informado (`AutoExitAdversarialWorld.sol:613-617`). | Verifica passivo, backing, rollback e semântica one-shot. |

Hashes SHA-256 dos arquivos de regressão relevantes:

- `contracts/test/v2/route/DominoSwapExecutorV3.t.sol`: `17d727ab8e2c6f41b24e347e9dda981366fbaff75d24b9a7e658b627320e957e`;
- `contracts/test/v2/adversarial/HopTokenBacking.t.sol`: `5b711e9fe0539c71e010f0e6edaef39ef552c01b2b2354f43a549e25031f318f`;
- `contracts/test/v2/adversarial/HostileOperator.t.sol`: `c871d2a5add8b56b5f13b4957b616f440f03d9f18ea718c2aa91894ead3bdb74`;
- `contracts/test/v2/adversarial/AutoExitAttacks.t.sol`: `2db3f6f7fec20071644d41d0daa724b6aefc7e897225a9d3559cc2646097d126`;
- `contracts/test/v2/adversarial/BuyTaxToken.sol`: `d8f0e5fa6f74cb32bd0c83d371c903d5ee085e093270ad8cec35524deed7f025`.

### Limites da cobertura de regressão

- O teste longo de rota prova um intermediário posterior (`h = 2`), mas seu último intermediário (`h = 3`) reutiliza `tokenIn`; portanto ele não isola todas as três posições internas com endereços distintos. A fonte revisada percorre corretamente todas (`h < hops`), mas a suíte não mataria necessariamente uma mutação que omitisse somente a última posição interna. Isso é uma lacuna de assurance, não uma falha observada na implementação.
- Não há regressão DV2-01 específica no host `DominoZapV4` usando uma perna V3. O código é o mesmo `DominoSwapExecutor` herdado por `DominoZapBase`, e o manifest confirma que `DominoZapV4` incorpora o delta, mas a cobertura direta por host V4 não foi adicionada.
- A execução real de todos esses testes permanece pendente do processo pai.

## Manifest, ABI e quatro contratos alterados

Comparação estática entre `contracts/release-artifacts-v2.json` no commit anterior e no candidato:

| Contrato | Bytecode | Creation bytes | Runtime bytes | ABI SHA-256 atual (igual ao anterior) |
|---|---|---:|---:|---|
| DominoAutoExit | alterado | 20526 → 20738 | 19710 → 19922 | `95ad0d197e4b8d240708398ac48e75de76559aa2768389e883e852997fd82df1` |
| DominoPriceAnchor | inalterado | 8288 | 7529 | `cf6c6223f4ed180640a572df685f37124ab7af517af1454f4865da6c1df17691` |
| DominoRegistry | inalterado | 8757 | 7091 | `21d036a1f4d258a8a44ebc089531bc423101204c8d3953b33e52365541867ef1` |
| DominoV2VaultExecutorV3 | inalterado | 20435 | 19688 | `a066f5102a00b7e9061e4c8ebffc6eee2211d6c4bd10b0d5c3de6f713b3329f5` |
| DominoV2VaultExecutorV4 | inalterado | 24203 | 23442 | `9397a2cfaeefb90bc35d543f3b12baf35b20b6a0ae40d064907eb6bc4f173df3` |
| DominoV2VaultFactory | inalterado | 2141 | 1470 | `ff550004d285734397ea10a1e6d89a99269173f9c8a261620e37cb38936c0772` |
| DominoV2VaultSwapModule | alterado | 7905 → 8117 | 7382 → 7594 | `ad88500fca391fa3bef5159721138693c039fb3a23e0c8a800afd9777f4cdfef` |
| DominoV2VaultV3 | inalterado | 37320 | 15923 | `cd811e896a09607f3fbd1035f6404d37e9864be3a744714676aee0c291cad958` |
| DominoV2VaultV4 | inalterado | 41141 | 15941 | `0b60add9a6e3a55b345949f62097fd6ffd1e4a202bb27c10d1d947eea31b78c8` |
| DominoZapV3 | alterado | 24509 → 24721 | 23554 → 23766 | `5d92c661daa820daf6640517214a5826e3295dcb042f0992851fab4d2e553b9e` |
| DominoZapV4 | alterado | 22018 → 22230 | 21110 → 21322 | `dc362a72d811b5e0913ba629e4a81ba8e07a574c5b685109f3997b98f2b8c331` |
| DominoZapV4Steps | inalterado | 7433 | 7394 | `70aa7fda496fa6042f9fd89cb496dd4f7452a74c0bfb7b8d56ff06d6d12fb542` |

Os quatro alterados cresceram exatamente 212 bytes em creation e runtime. Os hashes creation/runtime completos dos 12 membros, inclusive os valores anterior e atual dos quatro alterados, constam em `result.json`.

A presença dos quatro é coerente com a herança/uso:

- `DominoAutoExit` herda diretamente `DominoSwapExecutor`;
- `DominoV2VaultSwapModule` herda diretamente `DominoSwapExecutor`;
- `DominoZapV3` e `DominoZapV4` herdam `DominoZapBase`, que herda `DominoAssistedSwap`, que herda `DominoSwapExecutor`.

Os vault implementations e executors permanecem iguais porque a lógica de swap alterada reside no módulo separado usado por `delegatecall`.

## Evidência de mutação fornecida

O relatório fornecido `package/remediation/mutations/v2-audit-2026-10-04.json` tem SHA-256 `8b655aa99a84d8ef8ba005ca49bbc9927d0764f003dfbcd464a19c2fdcdd8387`. Ele registra batch SHA-256 `765ddc0bf42da56600224e92d3e208eb9e4ce0aaf402a835c7dbcc02bc42b82d`, confirmado contra `contracts/mutations/v2-audit-2026-10-04.json`.

Conjunto completo de fontes declarado e recomputado:

- `contracts/src/v2/autoexit/DominoAutoExit.sol`: `1ca56091254ce832577480cb1e1b268e5874555a4b07beec24eb8d1ddc15946c`;
- `contracts/src/v2/route/DominoSwapExecutor.sol`: `d850de22789e05db695b4e89ca18fcf4413f5a12e62b3f7fa348cd0ff90cd969`;
- `contracts/src/v2/vault/DominoV2VaultBase.sol`: `193420749d563b920d1b646dc81d25b3fef38ea9bddda0746fbe1ba13b9e5f68`.

Conjunto completo de suites declarado e recomputado:

- `test/v2/autoexit/DominoAutoExitExecute.t.sol`: `5553f05fd030a7c8fb1edef550c7f999a9eecd50ad2ea73482b727fad0066e54`;
- `test/v2/autoexit/DominoAutoExitMandate.t.sol`: `cba98ecc45eaea1d030ebaf352b5560f5dcf908cfa093e727dbc1ee23dc1ab89`;
- `test/v2/route/DominoSwapExecutorV3.t.sol`: `17d727ab8e2c6f41b24e347e9dda981366fbaff75d24b9a7e658b627320e957e`;
- `test/v2/vault/DominoV2VaultExit.t.sol`: `dea8f2c9dbe603ef4281ccfb70557396393c7ac6c3b23ac9da747dce3d5fd082`.

O batch contém dez mutações: cinco D-1/D-2 e cinco DV2-01. As cinco de DV2-01 removem o tracking, limitam o laço ao primeiro intermediário e removem separadamente cada um dos três checks estruturais (`contracts/mutations/v2-audit-2026-10-04.json:41-74`). O relatório fornecido marca as dez como `CAUGHT`, sem baseline failure (`package/remediation/mutations/v2-audit-2026-10-04.json:18-82`). Esse estado foi lido e seus membros/hashes foram confirmados; **não foi reproduzido nesta revisão**.

## Tokens não suportados e limites que não pertencem à correção original

A correção de DV2-01 cobre o caso original: um token intermediário cujo débito adicional é observável em seu `balanceOf`. Ela não transforma todo ERC-20 arbitrário em suportado.

Permanecem fora do modelo ou aceitos, sem serem apresentados como corrigidos por DV2-01:

- token double-entry/alias entre dois endereços: a contabilidade é por endereço; fees, reservas e créditos `unclaimed` na própria moeda podem ficar expostos pelo twin (`reports/V2_AUDIT_PACKAGE.md:163`, `:232-235`);
- `balanceOf` mentiroso: a checagem de efeito depende do saldo que o token reporta;
- sweeps best-effort de `exitAll`, `returnReserves` e `_release`: por decisão A8, podem preservar liveness em vez de recusar um token que debita mais; esse limite é distinto da rota V3 e está documentado em `contracts/src/v2/vault/DominoV2VaultStorage.sol:315-324` e `contracts/test/v2/adversarial/TokenMatrixVault.t.sol:244-264`;
- tokens intermediários cujo `balanceOf` não pode ser lido agora falham fechados; isso é requisito operacional introduzido pela preservação do saldo, não perda silenciosa de backing.

## Unknowns e conclusão de closure

Unknowns de execução:

1. As regressões entregues ainda não foram executadas por esta revisão; resultado runtime pertence ao processo pai.
2. As mutações foram apenas verificadas quanto a conteúdo, membros e hashes; seus verdicts não foram reproduzidos.
3. Os bytecodes não foram recompilados; os manifests versionados foram comparados integralmente e o arquivo do pacote foi autenticado por SHA-256.
4. O estado final de CI/tag não foi consultado; o registro fornecido é pré-tag.

Limites de assurance que não reabrem o achado:

1. O teste longo não isola a última posição intermediária com endereço distinto.
2. Não há regressão DV2-01 direta para uma perna V3 dentro de `DominoZapV4`, embora a herança e o bytecode manifestado incorporem a mesma correção.
3. A garantia continua dependente de saldo por endereço reportado corretamente pelo próprio token.

**Closure:** o escopo revisado suporta fechar DV2-01 como `fixed`, condicionado ao pai confirmar as regressões entregues no candidato exato. Não há aprovação ampla da release.