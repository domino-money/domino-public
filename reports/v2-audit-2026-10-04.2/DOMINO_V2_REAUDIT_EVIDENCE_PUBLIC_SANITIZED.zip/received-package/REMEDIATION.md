# Domino V2: the remediation of the `v2-audit-2026-10-04` audit

**For:** the auditors of `v2-audit-2026-10-04`, who returned REQUEST_CHANGES on 4 Oct 2026.

**What to check:** commit `559c509ff71d71e49ac720bd6acd8a9783531ebb` (tree `e5ed5db6404ae9d5464028690f788ea3a217ebbd`) of https://github.com/domino-money/domino, which is `main` after #323.

**Your files:** the report, findings, evidence and receipt you delivered are committed unchanged under `reports/v2-audit-2026-10-04/`, with their SHA-256 in that folder's README.

## 1. Identity and state

| | Audited | This candidate |
|---|---|---|
| Commit | `5e63d2db` | `559c509f` |
| Tag | `v2-audit-2026-10-04` (unchanged, never moved) | `v2-audit-2026-10-04.2`, **not cut yet** |
| Release manifest SHA-256 | `4f607c2f…6ebb` | `2975c377c6f3690a702fddeecfe4ffb2c4ccab6e52c8739f4877ce458f66ed5c` |
| `sourceTreeSha256` | `296008a4…5ad9` | `7a78b034fc09c924140173748b5a620cebd539d9635690adbda1154c0b95edfe` |
| PR CI on the identical tree | #319, run 37201444263, passed | #323, run 37220671110, passed |
| Main CI on the commit | run 37206891445: attempt 1 failed (DV2-02); attempt 2 rerun after the audit | run 37223288312, **in progress** when this package was made |

**The tag follows main's run on this commit (`docs/v2/FREEZE.md`).** It is cut only if that run passes. The repository then gets `reports/v2-audit-2026-10-04.2/freeze.json`, which differs from this package's `freeze.json` only in the tag object and that run's conclusion. If the run fails, no tag is cut on this commit, and you will be told.

**Since the audited commit, main took three merges:**
- #320: the audited freeze's record (`freeze.json`, as you received it);
- #321: featured pools, backend only (`backend/featured_policy.json` and its tests), outside the V2 scope;
- #323: this remediation.

`v2-remediation.patch` is the diff of every V2-scope path from `5e63d2db` to `559c509f`: `contracts/`, `scripts/`, `docs/v2/`, the package and this folder's records (33 files). Your four delivered files are left out of it.

## 2. What changed in the frozen scope

From `manifest-delta.json`:
- **One source:** `src/v2/route/DominoSwapExecutor.sol` (DV2-01).
- **One release input:** `scripts/v2/deploy.mjs` (DV2-05).
- **Compiler, components and ABIs:** unchanged.
- **Four contracts** carry the executor; each grew by 212 B, runtime and creation:
  - DominoAutoExit;
  - DominoV2VaultSwapModule;
  - DominoZapV3, now 810 B under EIP-170;
  - DominoZapV4.
- **The other eight** are byte for byte the audited ones: Registry, PriceAnchor, VaultV3, VaultV4, both executors, Factory, ZapV4Steps.

## 3. Findings and fixes

Locations are at `559c509f`.

### DV2-01 (medium): V3 intermediate tokens

**Fix:**
- `contracts/src/v2/route/DominoSwapExecutor.sol:430` `_trackedTokens` now adds every intermediate of each v3 path.
- `:452` `_includeHops` reads them only from a path that passes the same length checks as the swap (`:329`).
- A tracked token's balance must be unchanged after the leg (`_checkEffect`, "others unchanged"), so an over-debiting hop token reverts the leg with `SwapEffectMismatch`.

The other leg kinds never hold an intermediate in the host:
- the Universal Router leg approves only its input, through Permit2, for exactly `amountIn`, and requires that allowance spent;
- v4 hops net inside the PoolManager, and only the output is taken.

V2 is not deployed on a public chain (fork rehearsal only), so no asset was exposed.

**Regressions, one per host:**
- **Route:**
  - `contracts/test/v2/route/DominoSwapExecutorV3.t.sol:285`, an over-debiting intermediate;
  - `:300`, the third token of a four-hop path;
  - `:264`, malformed paths, whose addresses are never tracked.
- **Zap:** `contracts/test/v2/adversarial/HopTokenBacking.t.sol:200`.
- **Vault:** `contracts/test/v2/adversarial/HostileOperator.t.sol:200`, on the wired v3 world.
- **Auto-exit:** `contracts/test/v2/adversarial/AutoExitAttacks.t.sol:755`, a deferred delivery in the hop token.
- The over-debiting mode is `setOverdebited`, at `contracts/test/v2/adversarial/BuyTaxToken.sol:26`.

**Mutants:** `contracts/mutations/v2-audit-2026-10-04.json`, five DV2-01 entries (the tracking, every intermediate, each of the three path checks), all caught.

### DV2-02 (release blocker): main CI on the frozen commit

**Root cause:** a deploy-tool test left a transaction pending in Anvil. `evm_revert` restores state, not the transaction pool, so the transaction was mined into the next test's state and spent the deployer's nonce. That gave `nonce too low`, then `deployer_nonce_mismatch`.

**Fix:**
- `scripts/v2/deploy-preflight.test.mjs:36` `isolated()` drops every pending transaction before reverting.
- The nonce test drops its own pending transaction before it re-enables automine.
- The regression test `:184` proves that no transaction a test leaves pending reaches the next test.

**Proof:**
- Removing the drop reproduces CI's three failures, plus the new test's.
- The Backend job's command passes 54/54, locally under load with an empty compile cache, and in #323's run.

**Record:** `remediation/main-ci.json` records the audited commit's run as it happened. Attempt 2 is a rerun after your report; it is not presented as the audited commit's result.

### DV2-03 (low): cold instructions

**Fix:** `scripts/v2/audit-bootstrap.sh`. It runs four steps:
1. `npm ci` for the root and `app/`;
2. the seven V1 contracts the runner's size gate reads after every suite;
3. the twelve V2 contracts and `test/v2/integration/IntegrationArtifacts.sol`;
4. the manifest check.

**Proof:** on a fresh checkout with no `node_modules` and no artifacts, with this candidate's sources, scripts and manifest:
- "V2 audit build ready", and the manifest matches;
- `node scripts/test-contracts.mjs --match-path test/v2/adversarial/AutoExitInvariants.t.sol` passes 10/10.

### DV2-04 (low): mutation provenance

**Fix:**
- **The package's three claims are now committed batches.** Their edits are transcribed by program from the hand-run scripts' own lists, with the same suites:
  - `contracts/mutations/v2-auto-exit-adversarial-2026-10-03.json` (the "29 of 29");
  - `v2-registry-adversarial-2026-10-03.json` (the "18 of 18");
  - the D-1/D-2 entries of `v2-audit-2026-10-04.json` (the "5 of 5").

  Their results as recorded on 3 Oct, with the trees they ran on, are in `remediation/mutation-history.json`.
- **The eight stale vault substitutions you listed** are rewritten for the current text with the same intent. Three labels now name the caps #317 introduced. The two guards #317 added are in: the 300 s observation-age cap and the withdrawal's recipient.
- **The mutation runner** (`scripts/mutate-contracts.mjs`) gains:
  - `rebuild` (`:106`): suites that deploy a contract from its artifact see the mutant;
  - `suites`: several suites per mutation; any failure catches it, any tool failure voids it;
  - `--report` (`:246`): the verdicts with the SHA-256 of the batch, every source and every suite;
  - `--only`: named mutations of a committed batch.

  NOT APPLIED, NO BUILD and incomplete runs still fail the batch. Each addition is pinned by deleting it: 13 mutants, all caught by `scripts/mutate-contracts.test.mjs`.

**Reruns on this candidate,** in `remediation/mutations/`. Every source hash in each report equals this candidate's manifest entry.

| Batch | Run | Caught |
|---|---:|---:|
| `v2-auto-exit-adversarial-2026-10-03.json` | 29 | 29 |
| `v2-registry-adversarial-2026-10-03.json` | 18 | 18 |
| `v2-audit-2026-10-04.json` | 10 | 10 |
| `v2-vault-2026-10-02.json` (`--only`, the 10 rewritten or added) | 10 | 10 |

`v2-fees-route-2026-10-01.json` (117) was still running on this candidate when this package was made, with every row caught so far. Its report will come with the tag's freeze record. Every committed batch applies to this candidate's sources.

### DV2-05 (informational): RPC transport

**Fix:** `scripts/v2/deploy.mjs:433` `RPC_REPLY_MAX_BYTES` (8 MiB) bounds every reply (`rpc_reply_too_large: <method>`). `:449` `validReply` requires:
- a JSON-RPC 2.0 object;
- the request's id;
- exactly one of `result` or `error`;
- a null id only on an error.

Otherwise the reply is refused with `rpc_invalid_reply: <method>`. The retries and the 60 s timeout of `:460` `makeRpc`, and the read-only layer's call budget, are unchanged.

**Proof:** the transport test, `scripts/v2/deploy.test.mjs:425`, covers:
- a wrong id;
- no version, and an old version;
- both `result` and `error`, and neither;
- a batch;
- a null id with a result;
- not JSON;
- a null id with an error, which is a method failure;
- the cap.

Four guard mutants, all caught.

### The limits you asked to be stated plainly

- **B (double-entry):** everything kept per address in that token is exposed, the auto-exit's `unclaimed` credits too. The owner confirmed this restated scope on 4 Oct. See `reports/V2_AUDIT_PACKAGE.md` §5 and §7, and `docs/v2/F4_AUTO_EXIT.md:215`.
- **The v3 operator rearm:** it compares two checkpoints and cannot see the steps between them. Its slack is at most `g × (current − previous liquidity)` per token and has no small ceiling; "dust" is gone from the wording. See `docs/v2/F3_VAULT.md:115`.
- **The cost of `exitAll`:** there is no capacity certificate. The per-position exit is part of the runbook, in order: pause, disable the exit module, `withdrawChild` one by one, `withdrawReserves` per token. See `docs/v2/F3_VAULT.md:262`.
- **Lines:** 8,040 at the tag (the package said 8,039, one short in the vault's row); 8,062 now.

## 4. How to verify

```bash
git clone https://github.com/domino-money/domino && cd domino && git checkout 559c509ff71d71e49ac720bd6acd8a9783531ebb
git rev-parse HEAD^{tree}              # e5ed5db6404ae9d5464028690f788ea3a217ebbd
sh scripts/v2/audit-bootstrap.sh       # ends with "V2 audit build ready"
node scripts/test-contracts.mjs --match-path test/v2/route/DominoSwapExecutorV3.t.sol
node scripts/test-contracts.mjs --match-path test/v2/adversarial/AutoExitAttacks.t.sol
node scripts/mutate-contracts.mjs contracts/mutations/v2-audit-2026-10-04.json --with-artifacts --report=/tmp/v2-audit.json
node --test scripts/v2/deploy.test.mjs scripts/v2/deploy-preflight.test.mjs scripts/v2/deploy-schema.test.mjs scripts/v2/deploy-fork.test.mjs scripts/v2/release-manifest.test.mjs
```

Run one suite at a time; a whole-tree run exhausts solc-js memory. Any committed batch reruns the same way. A report's `sources` hashes can be compared with `contracts/release-artifacts-v2.json`.

## 5. In this package

| File | What |
|---|---|
| `V2_AUDIT_PACKAGE.md` | The audit package, as committed at `559c509f` |
| `freeze.json` | This candidate's freeze record **before the tag** (stage `pre-tag`) |
| `REMEDIATION.md` | This document |
| `release-artifacts-v2.json` | The candidate's release manifest |
| `manifest-delta.json` | What changed between the two manifests |
| `v2-remediation.patch` | The V2-scope diff from `5e63d2db` to `559c509f` |
| `remediation/main-ci.json` | Main's run on the audited commit, both attempts |
| `remediation/mutation-history.json` | The 3 Oct campaigns, as recorded |
| `remediation/mutations/*.json` | The reruns on this candidate |
| `SHA256SUMS` | The SHA-256 of every file above |
