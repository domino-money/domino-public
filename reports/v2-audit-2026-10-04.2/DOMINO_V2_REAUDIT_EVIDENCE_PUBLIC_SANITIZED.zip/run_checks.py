from pathlib import Path
import subprocess,json,time,os,datetime
r=Path(__file__).parent;s=r/'source';e=r/'evidence/checks';e.mkdir(exist_ok=True);rows=[]
env=os.environ.copy();env['TMPDIR']=str(r);env['DOMINO_V2_COMPILE_CACHE']=str(e/'deployment-compile-cache')
def run(name,args,cwd=s,timeout=1800):
 start=time.monotonic();print('START',name,datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
 with (e/(name+'.log')).open('w') as f:
  try:code=subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout).returncode
  except subprocess.TimeoutExpired:code=124
 row={'name':name,'command':args,'cwd':str(cwd),'exit_code':code,'seconds':time.monotonic()-start,'log':str(e/(name+'.log'))};rows.append(row);(e/'results.json').write_text(json.dumps(rows,indent=2));print('END',name,code,round(row['seconds'],1),flush=True);return code==0
assert not(s/'node_modules').exists() and not(s/'app/node_modules').exists() and not(s/'contracts/out').exists() and not(s/'contracts/cache').exists()
(e/'cold-precondition.json').write_text(json.dumps({'node_modules_absent':True,'app_node_modules_absent':True,'out_absent':True,'cache_absent':True},indent=2))
if not run('01-cold-bootstrap',['sh','scripts/v2/audit-bootstrap.sh']):raise SystemExit(1)
# The exact previously failing example, now on the fixed bootstrap.
suites=['test/v2/adversarial/AutoExitInvariants.t.sol','test/v2/route/DominoSwapExecutorV3.t.sol','test/v2/adversarial/HopTokenBacking.t.sol','test/v2/adversarial/HostileOperator.t.sol','test/v2/adversarial/AutoExitAttacks.t.sol']
tracked=subprocess.check_output(['git','ls-files','contracts/test/v2/route','contracts/test/v2/invariant'],cwd=s,text=True).splitlines()
suites+=sorted(p.removeprefix('contracts/') for p in tracked if p.endswith('.t.sol') and p.removeprefix('contracts/') not in suites)
suites+=['test/v2/vault/DominoV2VaultSwapModule.t.sol']
assert len(suites)==len(set(suites));(e/'expected-suites.json').write_text(json.dumps(suites,indent=2))
for i,p in enumerate(suites):run(f'suite-{i:02d}-'+Path(p).stem,['node','scripts/test-contracts.mjs','--match-path',p])
run('deploy-tooling',['node','--test','scripts/v2/deploy.test.mjs','scripts/v2/deploy-preflight.test.mjs','scripts/v2/deploy-schema.test.mjs','scripts/v2/deploy-fork.test.mjs','scripts/v2/release-manifest.test.mjs'])
run('evidence-runner-tests',['node','--test','scripts/mutate-contracts.test.mjs','scripts/test-contracts.test.mjs','scripts/check-contract-size.test.mjs','scripts/gas-baseline.test.mjs'])
for name,args in [('abi',['node','scripts/v2/export-abi.mjs','--check']),('fixtures',['node','scripts/v2/position-fixtures.mjs','check']),('hygiene',['node','scripts/check-contract-hygiene.mjs']),('final-manifest',['node','scripts/v2/release-manifest.mjs','--check','--forge-out','contracts/out']),('final-status',['git','status','--porcelain'])]:run(name,args)
print('COMPLETE',len(rows),'failed',sum(x['exit_code']!=0 for x in rows),flush=True)
raise SystemExit(int(any(x['exit_code']!=0 for x in rows)))
