# Domino V2 — triagem integral dos resultados Slither

## Escopo e veredito

- Fonte congelada: commit `5e63d2dba9123fdc585f7f272b83532b491fbc51`, tree `db8bfb4e57a043a94f7fe55bf02725cb65836b1c`.
- Scanner recebido: Slither 0.11.6, 52 fontes V2, solc-js 0.8.26, viaIR/200, Cancun, bytecodeHash none.
- Entrada: `[WORKSPACE]/results.json` (SHA-256 `3a2b76e1326b026180bbae716e4fed18a1050a9d85b6dfba7488c0105477058f`).
- Contexto de risco aceito: `[USER_HOME]/.hermes/cache/scratch/domino-v2-audit-20261004/evidence/doc_a9ad340e5ed4_V2_AUDIT_PACKAGE.md` (SHA-256 `1f91dc44bdd8d7ab18c73675a9092f11e4a420b5ccfc3551ffe8fda33f2d8bf1`).
- Probe offline estreito: `[USER_HOME]/.hermes/cache/scratch/domino-v2-audit-20261004/evidence/slither-triage/probe-results.json` (SHA-256 `c8c61013a1f2c78c470cad85ad19be06fb8fcc0bb6434785a06f2382cbe3f04e`): 10 arquivos vendorizados iguais à referência normalizada e 42768 denominadores ímpares válidos para a identidade do inverso FullMath.
- Índices neste relatório e no JSON são zero-based e correspondem diretamente à ordem de `results.detectors`.
- Cobertura: 352/352 resultados, 352 IDs únicos, 27 tipos de detector presentes.
- Classificação: 0 questão confirmada; 147 falsos positivos; 205 aceitos/informacionais; 0 não verificados.
- Veredito limitado: nenhum resultado do scanner fornecido confirma vulnerabilidade neste tree. Isso não é prova de ausência geral de defeitos e não incorpora as suites ou auditorias paralelas do parent.

## Critérios aplicados aos alertas sensíveis

- Delegatecall do zap v4: alvo `STEPS` imutável, selector fixo, callback limitado ao PoolManager e ao hash transient do payload pendente.
- Dispatcher do vault: o `return` em assembly é terminal e encaminha returndata bruto intencionalmente.
- Executor/módulo do vault: layout de storage é deliberadamente compartilhado por delegatecall; análise isolada do executor produz estado aparentemente não inicializado/constante.
- FullMath/BitMath/TickMath: operações XOR, shifts e ordem divisão/multiplicação são algoritmos upstream vendorizados; o probe confirmou igualdade normalizada com a referência oficial.
- Reentrância: ações, fee flush e executor compartilham uma trava transient; callbacks são autenticados por caller e contexto/hash pendente.
- Unused return: nos fluxos monetários apontados, o dado autoritativo é o delta real de balanceOf; retornos auxiliares são deliberadamente ignorados.
- Loops com calls: legs e hops são limitados a 8 e 4; membros são limitados por uint8. O custo de `exitAll` é risco aceito no pacote §7.

## Contagens por detector

- `assembly`: 57 — confirmado 0, falso positivo 0, aceito/info 57, não verificado 0
- `calls-loop`: 86 — confirmado 0, falso positivo 0, aceito/info 86, não verificado 0
- `constable-states`: 21 — confirmado 0, falso positivo 21, aceito/info 0, não verificado 0
- `controlled-delegatecall`: 1 — confirmado 0, falso positivo 1, aceito/info 0, não verificado 0
- `costly-loop`: 1 — confirmado 0, falso positivo 0, aceito/info 1, não verificado 0
- `cyclomatic-complexity`: 5 — confirmado 0, falso positivo 0, aceito/info 5, não verificado 0
- `dead-code`: 1 — confirmado 0, falso positivo 0, aceito/info 1, não verificado 0
- `divide-before-multiply`: 12 — confirmado 0, falso positivo 12, aceito/info 0, não verificado 0
- `immutable-states`: 1 — confirmado 0, falso positivo 1, aceito/info 0, não verificado 0
- `incorrect-exp`: 1 — confirmado 0, falso positivo 1, aceito/info 0, não verificado 0
- `incorrect-return`: 1 — confirmado 0, falso positivo 1, aceito/info 0, não verificado 0
- `incorrect-shift`: 2 — confirmado 0, falso positivo 2, aceito/info 0, não verificado 0
- `low-level-calls`: 11 — confirmado 0, falso positivo 0, aceito/info 11, não verificado 0
- `missing-inheritance`: 2 — confirmado 0, falso positivo 0, aceito/info 2, não verificado 0
- `missing-zero-check`: 3 — confirmado 0, falso positivo 3, aceito/info 0, não verificado 0
- `naming-convention`: 27 — confirmado 0, falso positivo 0, aceito/info 27, não verificado 0
- `reentrancy-benign`: 6 — confirmado 0, falso positivo 6, aceito/info 0, não verificado 0
- `reentrancy-eth`: 2 — confirmado 0, falso positivo 2, aceito/info 0, não verificado 0
- `reentrancy-events`: 4 — confirmado 0, falso positivo 4, aceito/info 0, não verificado 0
- `reentrancy-no-eth`: 2 — confirmado 0, falso positivo 2, aceito/info 0, não verificado 0
- `shadowing-local`: 1 — confirmado 0, falso positivo 0, aceito/info 1, não verificado 0
- `timestamp`: 9 — confirmado 0, falso positivo 1, aceito/info 8, não verificado 0
- `too-many-digits`: 5 — confirmado 0, falso positivo 0, aceito/info 5, não verificado 0
- `uninitialized-local`: 19 — confirmado 0, falso positivo 19, aceito/info 0, não verificado 0
- `uninitialized-state`: 23 — confirmado 0, falso positivo 23, aceito/info 0, não verificado 0
- `unused-return`: 32 — confirmado 0, falso positivo 32, aceito/info 0, não verificado 0
- `unused-state`: 17 — confirmado 0, falso positivo 16, aceito/info 1, não verificado 0

## Questões confirmadas

Nenhum.

## Falsos positivos

### `delegatecall-zap-controlado` (1)

- [000] `5c4033f609d28a9de61ca078a0ab236e23111ce7a03d4a651c08acb31b3ae1d7` — `controlled-delegatecall` — `src/v2/zap/DominoZapV4.sol#L62-L82`
  - Motivo: Falso positivo: STEPS é imutável e exige código no construtor (ZapV4:41-50); `_run` grava keccak256(data) imediatamente antes do unlock (146-152); o callback aceita somente V4_POOL_MANAGER e o mesmo hash (62-75), prefixa um selector fixo de `run`, e o módulo recusa chamada direta (Steps:37-46). Nem alvo nem função são controláveis pelo input externo.

### `fullmath-xor` (1)

- [001] `be9746e2d4af10bd3084cb1a33c11cd11e06a024aade58e53eb110683f82f488` — `incorrect-exp` — `src/v2/positions/uniswap/FullMath.sol#L14-L102`
  - Motivo: Falso positivo: `^ 2` é XOR intencional, a semente de quatro bits do inverso modular de denominador ímpar; seis passos Newton-Raphson elevam a precisão a 256 bits (FullMath:77-100). O arquivo coincide com a referência oficial e o probe confirmou denominator*inv mod 2^256 == 1.

### `retorno-terminal-proxy` (1)

- [002] `b6398a31cf8edb4705d4be591385a217e834cb926eb03c0f277c41f0e2e5c0c9` — `incorrect-return` — `src/v2/vault/DominoV2VaultBase.sol#L369-L371`
  - Motivo: Falso positivo: `return(add(result,32),mload(result))` é terminal de assembly deliberado do dispatcher; ele devolve exatamente o returndata do delegatecall e encerra a chamada externa, assim como o ramo de erro propaga o revert (VaultBase:379-387).

### `lock-reentrancia` (11)

- [003] `03dea147d6ed46745aa882434ccf72f7528243fd0f233decefdd9d9bc1de34e5` — `reentrancy-eth` — `src/v2/autoexit/DominoAutoExit.sol#L356-L386`
  - Motivo: Falso positivo: o entry point correspondente usa `nonReentrant`; DominoActionLock usa um único slot transient compartilhado também por fee ledger e swap executor (ActionLock:4-30). Callbacks v3/v4 têm autenticação por pool/manager e contexto/hash pendente (SwapExecutor:163-224), portanto as escritas/eventos posteriores não ficam expostos a uma segunda ação.
- [004] `92b5cbfb8abd2cb783afbd27bba535acc2ea48d45dbf014438cec7254c1cbd13` — `reentrancy-eth` — `src/v2/zap/DominoZapBase.sol#L151-L215`
  - Motivo: Falso positivo: o entry point correspondente usa `nonReentrant`; DominoActionLock usa um único slot transient compartilhado também por fee ledger e swap executor (ActionLock:4-30). Callbacks v3/v4 têm autenticação por pool/manager e contexto/hash pendente (SwapExecutor:163-224), portanto as escritas/eventos posteriores não ficam expostos a uma segunda ação.
- [042] `acdad2a90329de9fd9482e173c609178339b7da91947411df01a14f06d16cb5b` — `reentrancy-no-eth` — `src/v2/vault/DominoV2VaultBase.sol#L262-L267`
  - Motivo: Falso positivo: o entry point correspondente usa `nonReentrant`; DominoActionLock usa um único slot transient compartilhado também por fee ledger e swap executor (ActionLock:4-30). Callbacks v3/v4 têm autenticação por pool/manager e contexto/hash pendente (SwapExecutor:163-224), portanto as escritas/eventos posteriores não ficam expostos a uma segunda ação.
- [043] `c4c307d5307714a2515fb6abd6200a6e578ff7acde8c7188f91e234a41eca6df` — `reentrancy-no-eth` — `src/v2/vault/DominoV2VaultBase.sol#L298-L322`
  - Motivo: Falso positivo: o entry point correspondente usa `nonReentrant`; DominoActionLock usa um único slot transient compartilhado também por fee ledger e swap executor (ActionLock:4-30). Callbacks v3/v4 têm autenticação por pool/manager e contexto/hash pendente (SwapExecutor:163-224), portanto as escritas/eventos posteriores não ficam expostos a uma segunda ação.
- [185] `3bb0b1b052f66fa3f3b7ec254f3b4b02be5e0ca7d74bcd78cb5dfe7edb140ec1` — `reentrancy-benign` — `src/v2/vault/DominoV2VaultExecutor.sol#L55-L112`
  - Motivo: Falso positivo: o entry point correspondente usa `nonReentrant`; DominoActionLock usa um único slot transient compartilhado também por fee ledger e swap executor (ActionLock:4-30). Callbacks v3/v4 têm autenticação por pool/manager e contexto/hash pendente (SwapExecutor:163-224), portanto as escritas/eventos posteriores não ficam expostos a uma segunda ação.
- [186] `5046b00e0aa5232000ef02f4df7acd07b2bcf2cb2fb43eb975f742c938dfffb9` — `reentrancy-benign` — `src/v2/autoexit/DominoAutoExit.sol#L178-L191`
  - Motivo: Falso positivo: o entry point correspondente usa `nonReentrant`; DominoActionLock usa um único slot transient compartilhado também por fee ledger e swap executor (ActionLock:4-30). Callbacks v3/v4 têm autenticação por pool/manager e contexto/hash pendente (SwapExecutor:163-224), portanto as escritas/eventos posteriores não ficam expostos a uma segunda ação.
- [187] `55df182c156623e26a5862ace7a7599eb44f094550c48b1cfe654966ac784a56` — `reentrancy-benign` — `src/v2/route/DominoAssistedSwap.sol#L24-L43`
  - Motivo: Falso positivo: o entry point correspondente usa `nonReentrant`; DominoActionLock usa um único slot transient compartilhado também por fee ledger e swap executor (ActionLock:4-30). Callbacks v3/v4 têm autenticação por pool/manager e contexto/hash pendente (SwapExecutor:163-224), portanto as escritas/eventos posteriores não ficam expostos a uma segunda ação.
- [189] `a52b24d35125115ba9840cb6abbe6e8852a0e4a75f7768c597bfd4ec791cd9c5` — `reentrancy-benign` — `src/v2/vault/DominoV2VaultBase.sol#L298-L322`
  - Motivo: Falso positivo: o entry point correspondente usa `nonReentrant`; DominoActionLock usa um único slot transient compartilhado também por fee ledger e swap executor (ActionLock:4-30). Callbacks v3/v4 têm autenticação por pool/manager e contexto/hash pendente (SwapExecutor:163-224), portanto as escritas/eventos posteriores não ficam expostos a uma segunda ação.
- [190] `e74f7cfe1ee0efcf47d8345e4edc52a1e68637832e8e930bc6aec1d6c73f03b4` — `reentrancy-benign` — `src/v2/autoexit/DominoAutoExit.sol#L356-L386`
  - Motivo: Falso positivo: o entry point correspondente usa `nonReentrant`; DominoActionLock usa um único slot transient compartilhado também por fee ledger e swap executor (ActionLock:4-30). Callbacks v3/v4 têm autenticação por pool/manager e contexto/hash pendente (SwapExecutor:163-224), portanto as escritas/eventos posteriores não ficam expostos a uma segunda ação.
- [193] `648a2c03c35d467dd563975a124c34c0770f3916207ee5965a3aa1c538d8fd2b` — `reentrancy-events` — `src/v2/route/DominoAssistedSwap.sol#L24-L43`
  - Motivo: Falso positivo: o entry point correspondente usa `nonReentrant`; DominoActionLock usa um único slot transient compartilhado também por fee ledger e swap executor (ActionLock:4-30). Callbacks v3/v4 têm autenticação por pool/manager e contexto/hash pendente (SwapExecutor:163-224), portanto as escritas/eventos posteriores não ficam expostos a uma segunda ação.
- [194] `fe7b0d441412d290bfcfb9fd06e36e5d8e49f5a0afcff004292a11270fdd90f6` — `reentrancy-events` — `src/v2/route/DominoSwapExecutor.sol#L133-L154`
  - Motivo: Falso positivo: o entry point correspondente usa `nonReentrant`; DominoActionLock usa um único slot transient compartilhado também por fee ledger e swap executor (ActionLock:4-30). Callbacks v3/v4 têm autenticação por pool/manager e contexto/hash pendente (SwapExecutor:163-224), portanto as escritas/eventos posteriores não ficam expostos a uma segunda ação.

### `bitmath-shifts` (2)

- [005] `8c556aa7366cdc7f7e8ff04ab450a007bfcc5b95cdbb0536df509cb7dfccdfcf` — `incorrect-shift` — `src/v2/positions/uniswap/BitMath.sol#L31-L48`
  - Motivo: Falso positivo: os shifts encadeados são tabelas De Bruijn/Solady intencionais para MSB/LSB (BitMath:8-48), não tentativa de deslocar por uma expressão aritmética comum. O arquivo coincide com a referência oficial vendorizada.
- [006] `f439d7bbddaf017117e6b4be48b7256f1384b87720c549acc6084f42776002ec` — `incorrect-shift` — `src/v2/positions/uniswap/BitMath.sol#L12-L25`
  - Motivo: Falso positivo: os shifts encadeados são tabelas De Bruijn/Solady intencionais para MSB/LSB (BitMath:8-48), não tentativa de deslocar por uma expressão aritmética comum. O arquivo coincide com a referência oficial vendorizada.

### `storage-compartilhado` (23)

- [007] `0207d47c3b9ddf336feca7c72d43773dacccd4f8dcbda8822239a88647273783` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L110`
  - Motivo: Falso positivo de análise intercontrato: `_exitModule` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:315-318,346-351. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [008] `15d92814260df66434beadfeee4cb14de8e39d1d7d91baca6aa8d2f845459c02` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L86`
  - Motivo: Falso positivo de análise intercontrato: `_inverse` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:164-169. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [009] `1cb7f15ddc05ffcc0b0375f77ec8362cf55aedec2739c70fc4817b15b2f319bc` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L93`
  - Motivo: Falso positivo de análise intercontrato: `_maxPositions` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:391-403. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [010] `1d2da21fc59135913b4445b4e875013e5f27e4ffa06816cfc072bcaef8bdbc85` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L80`
  - Motivo: Falso positivo de análise intercontrato: `_owner` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:146-175 (atribuição na linha 154). Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [011] `1deeab5f9bd6de729bdeb64c0d5aad5ac2ad9ff09b904b278ad51ad4df217bd8` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L104`
  - Motivo: Falso positivo de análise intercontrato: `_fee` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:155-161. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [012] `3a9fd5c3c36c6c35098a88c8d1c11895dbb4ac2b296dd39bb173d30eb6f1706e` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L95`
  - Motivo: Falso positivo de análise intercontrato: `_maxPriceImpactBps` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:405-415. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [013] `638c8b10db9d89fa1983afd7f905fd939d64754fc547aefea344dbdfce449fca` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L108`
  - Motivo: Falso positivo de análise intercontrato: `_rootTokenId` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:148-163. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [014] `6674a9cd01ebc3b0da3462fed1ab2930845dd4cfcb995ae3fb8979f2b4efbb92` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L104`
  - Motivo: Falso positivo de análise intercontrato: `_fee` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:155-161. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [015] `737ad7ae369d153f917094567f96f778eade30eaa1e7f2073ab4949497217d58` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L106`
  - Motivo: Falso positivo de análise intercontrato: `_currency1` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:155-161. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [016] `76cb7b7b76377a80baac21d788c076fdcd87f538b38b6f4caed3ff02357e49b5` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L82`
  - Motivo: Falso positivo de análise intercontrato: `_paused` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:171,194-207,314. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [017] `78d6115187c1c4f2d39d61a159dc3d50ba2ec58461bd75e3f2305a3beb020295` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L89`
  - Motivo: Falso positivo de análise intercontrato: `_mode` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:391-403. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [018] `8987acced0f51dc870d9309b91f82a98da04e6972ea6816bdf3ab0f4237548d0` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L98`
  - Motivo: Falso positivo de análise intercontrato: `_lastExecutionAt` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultExecutor.sol:62-63,107-108. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [019] `93daf9dcf031ae643ba0271422f1f9b77cca47853f1a858f902aff3aca78b875` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L80`
  - Motivo: Falso positivo de análise intercontrato: `_owner` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:146-175 (atribuição na linha 154). Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [020] `9e1b4837beae6a1ce39fff77a2f013aa05ea56429152810e5cbec82cae7b2377` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L107`
  - Motivo: Falso positivo de análise intercontrato: `_hooks` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:155-161. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [021] `a5155b3619605e21bfe58c917ed856684f29961af4fe55514aab40ac1127b6e2` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L90`
  - Motivo: Falso positivo de análise intercontrato: `_triggerDistanceBps` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:391-403. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [022] `b372c8dfc325b66338ae972be434751795fe62ee6f397e5ea6cbd34e44f8f3ef` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L105`
  - Motivo: Falso positivo de análise intercontrato: `_tickSpacing` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:155-161. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [023] `ba80342d86fb6cf2541e9fcc9897c92f03031434ce816fdf3e3af64efec2a981` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L103`
  - Motivo: Falso positivo de análise intercontrato: `_currency0` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:155-161. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [024] `c1948b1028e3f62ba65cbd195a41d006390ecb6cb22e1ce5e63cabf7ff8a4e64` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L96`
  - Motivo: Falso positivo de análise intercontrato: `_maxObservationAgeSeconds` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:405-415. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [025] `cbb0d876e549e324a0392cfb3f4a0cdb0f77bdb34a067fb88d72640429d2fafd` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L94`
  - Motivo: Falso positivo de análise intercontrato: `_maxSlippageBps` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:405-415. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [026] `d2d305a4f1cecceecd5eaa45476a03578761ca3ed69451b7bc3905e781f21a0e` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L91`
  - Motivo: Falso positivo de análise intercontrato: `_maxOverlapBps` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:391-403. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [027] `ec8c61b2ba724fd035bb78037d9c9838c310f6da1f086b9c84127fc11522a4cf` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L108`
  - Motivo: Falso positivo de análise intercontrato: `_rootTokenId` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:148-163. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [028] `f158f0834a977cc71703a4a53f5f3b29bdeedd4eb218739812d51c01d02b6c66` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L97`
  - Motivo: Falso positivo de análise intercontrato: `_upsideBps` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:405-415. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.
- [029] `f829946b7ee580b61cb8b3d0fa00f84e629bac18180fe973e00319b2bdc110c6` — `uninitialized-state` — `src/v2/vault/DominoV2VaultStorage.sol#L92`
  - Motivo: Falso positivo de análise intercontrato: `_minimumIntervalSeconds` vive no layout comum Storage; o clone o inicializa/modifica pelo implementation e o Executor o lê/escreve por DELEGATECALL no mesmo storage (Storage:18-28; Base:356-387). Escritas relevantes: DominoV2VaultBase.sol:391-403. Chamadas diretas ao executor são recusadas por SELF ou pelo estado zero.

### `tickmath-divisao` (3)

- [030] `275e36b403da17a8c78f71364d4a64dca628fa72c8496f3126ccd4289720c354` — `divide-before-multiply` — `src/v2/positions/uniswap/TickMath.sol#L57-L114`
  - Motivo: Falso positivo: TickMath usa divisão inteira e shifts deliberados: max/minUsableTick truncam para o múltiplo utilizável de tickSpacing, e getSqrtPriceAtTick executa aritmética Q128.128 vendorizada (TickMath:38-114).
- [034] `7fd38bf88767527e93d4442b81e15aee35d91cfa6c3bc8f3525e593c1cf77367` — `divide-before-multiply` — `src/v2/positions/uniswap/TickMath.sol#L39-L43`
  - Motivo: Falso positivo: TickMath usa divisão inteira e shifts deliberados: max/minUsableTick truncam para o múltiplo utilizável de tickSpacing, e getSqrtPriceAtTick executa aritmética Q128.128 vendorizada (TickMath:38-114).
- [039] `b926961761c8b5547823ea3e5680da0118c58f1a604fd2f378a873f8e837658a` — `divide-before-multiply` — `src/v2/positions/uniswap/TickMath.sol#L46-L50`
  - Motivo: Falso positivo: TickMath usa divisão inteira e shifts deliberados: max/minUsableTick truncam para o múltiplo utilizável de tickSpacing, e getSqrtPriceAtTick executa aritmética Q128.128 vendorizada (TickMath:38-114).

### `fullmath-divisao` (8)

- [031] `2be2e3bacb22b27093d781742dc2189b1afae54d8466d85c291770e362b78a82` — `divide-before-multiply` — `src/v2/positions/uniswap/FullMath.sol#L14-L102`
  - Motivo: Falso positivo: as divisões removem fatores de dois de um produto 512-bit já tornado divisível exatamente; as multiplicações seguintes recompõem bits e aplicam o inverso modular (FullMath:44-100), sem perda de precisão decimal.
- [032] `4fb2c95c2fe5cbd174760fddd147b2025e4a98ade0822f1a82a706213d639855` — `divide-before-multiply` — `src/v2/positions/uniswap/FullMath.sol#L14-L102`
  - Motivo: Falso positivo: as divisões removem fatores de dois de um produto 512-bit já tornado divisível exatamente; as multiplicações seguintes recompõem bits e aplicam o inverso modular (FullMath:44-100), sem perda de precisão decimal.
- [035] `a5f55f47bc0d474696a97bc087f6fc3fe740b89a8300d51133effcda84ecb26c` — `divide-before-multiply` — `src/v2/positions/uniswap/FullMath.sol#L14-L102`
  - Motivo: Falso positivo: as divisões removem fatores de dois de um produto 512-bit já tornado divisível exatamente; as multiplicações seguintes recompõem bits e aplicam o inverso modular (FullMath:44-100), sem perda de precisão decimal.
- [036] `a7796726e31c0fb93b03af3fe83971e051ec5dc70ed4693d5d87b2c20b839024` — `divide-before-multiply` — `src/v2/positions/uniswap/FullMath.sol#L14-L102`
  - Motivo: Falso positivo: as divisões removem fatores de dois de um produto 512-bit já tornado divisível exatamente; as multiplicações seguintes recompõem bits e aplicam o inverso modular (FullMath:44-100), sem perda de precisão decimal.
- [037] `ac09a97e93b73d05b3722c296eac9bdb345c25d92e53f34cc985df3ef78b54e1` — `divide-before-multiply` — `src/v2/positions/uniswap/FullMath.sol#L14-L102`
  - Motivo: Falso positivo: as divisões removem fatores de dois de um produto 512-bit já tornado divisível exatamente; as multiplicações seguintes recompõem bits e aplicam o inverso modular (FullMath:44-100), sem perda de precisão decimal.
- [038] `b7513e544bf74345f4345c31bb41d696fa348738e7c45306d238ba7b2f007ad8` — `divide-before-multiply` — `src/v2/positions/uniswap/FullMath.sol#L14-L102`
  - Motivo: Falso positivo: as divisões removem fatores de dois de um produto 512-bit já tornado divisível exatamente; as multiplicações seguintes recompõem bits e aplicam o inverso modular (FullMath:44-100), sem perda de precisão decimal.
- [040] `d56ec7d78cdb4b6e11b9e284aa4d0c6eecd9b6b578c3b13dc523353682132486` — `divide-before-multiply` — `src/v2/positions/uniswap/FullMath.sol#L14-L102`
  - Motivo: Falso positivo: as divisões removem fatores de dois de um produto 512-bit já tornado divisível exatamente; as multiplicações seguintes recompõem bits e aplicam o inverso modular (FullMath:44-100), sem perda de precisão decimal.
- [041] `f5863d9bf15d8b299ad9f1aa9cdeac27ce2b55f93d5465f9013d1b6654c59bb6` — `divide-before-multiply` — `src/v2/positions/uniswap/FullMath.sol#L14-L102`
  - Motivo: Falso positivo: as divisões removem fatores de dois de um produto 512-bit já tornado divisível exatamente; as multiplicações seguintes recompõem bits e aplicam o inverso modular (FullMath:44-100), sem perda de precisão decimal.

### `customrevert-alinhamento` (1)

- [033] `57def03c71f3e05fa3dd2540914a3f703f830b16444ddc6764d614f2424bb0d3` — `divide-before-multiply` — `src/v2/positions/uniswap/CustomRevert.sol#L83-L119`
  - Motivo: Falso positivo: `mul(div(add(returndatasize(),31),32),32)` arredonda deliberadamente o tamanho ABI para o próximo múltiplo de 32 (CustomRevert:89-117); não é cálculo financeiro.

### `locais-zero` (19)

- [044] `0ad5bf11dbadbc8bd10a15e32d1f1541eb1f5e867e935c89ed270c504f712dc7` — `uninitialized-local` — `src/v2/fees/DominoFeeRules.sol#L72`
  - Motivo: Falso positivo: `delivered` é acumulador/flag/índice cujo zero inicial é semântico em Solidity; as somas, limites ou atribuições subsequentes cobrem todos os caminhos antes de qualquer uso não nulo.
- [045] `2e2260b97aa6c693547c5580d012030175c29e5e9c635c6405fe879ce55e1ec1` — `uninitialized-local` — `src/v2/positions/DominoV4Positions.sol#L362`
  - Motivo: Falso positivo: `i` é acumulador/flag/índice cujo zero inicial é semântico em Solidity; as somas, limites ou atribuições subsequentes cobrem todos os caminhos antes de qualquer uso não nulo.
- [046] `2e93a198acebbeb908b629abdf3e5de036005935bdfc34ab3b9b7ca24003af50` — `uninitialized-local` — `src/v2/vault/DominoV2VaultExecutor.sol#L255`
  - Motivo: Falso positivo: `max1` é acumulador/flag/índice cujo zero inicial é semântico em Solidity; as somas, limites ou atribuições subsequentes cobrem todos os caminhos antes de qualquer uso não nulo.
- [047] `426f2d7f2cc4aa2de2fb4492e86631ae1ce3e0bb4aa9273a81e7d40d0abd2d89` — `uninitialized-local` — `src/v2/vault/DominoV2VaultExecutor.sol#L254`
  - Motivo: Falso positivo: `max0` é acumulador/flag/índice cujo zero inicial é semântico em Solidity; as somas, limites ou atribuições subsequentes cobrem todos os caminhos antes de qualquer uso não nulo.
- [048] `43a37a7750f2cea33c0dc3fbd0b38922ae10ebffa71fe0701f6571cdbcab7cc1` — `uninitialized-local` — `src/v2/zap/DominoZapBase.sol#L107`
  - Motivo: Falso positivo: `none` é uma struct de Permit2 deliberadamente vazia, passada apenas pelas rotas BY_CALLER/BY_SIGNATURE; _act só consome permit quando by==BY_PERMIT.
- [049] `65275190a0399e448da7814ccc7fa293c707492d5478e93b9f65d6482497d638` — `uninitialized-local` — `src/v2/vault/DominoV2VaultExecutor.sol#L122`
  - Motivo: Falso positivo: `_validate` atribui destination em ambos os ramos aceitos, ACTION_COMPOUND (122-130) e ACTION_MINT (131-136); qualquer outra action reverte.
- [050] `676f6f50d01a34e33f4bf7bd5bdf44df48ff253a61086b07c4a807ac9299fc35` — `uninitialized-local` — `src/v2/fees/DominoFeeRules.sol#L71`
  - Motivo: Falso positivo: `spent` é acumulador/flag/índice cujo zero inicial é semântico em Solidity; as somas, limites ou atribuições subsequentes cobrem todos os caminhos antes de qualquer uso não nulo.
- [051] `911ccfe43e693cd60cdb52ad17c4d02cffdf4b1efadb9c1376d6d799ec19aad0` — `uninitialized-local` — `src/v2/vault/DominoV2VaultExecutor.sol#L116`
  - Motivo: Falso positivo: zero é o sentinela inicial deliberado das listas estritamente crescentes de tokenId (Executor:115-149).
- [052] `935c880f7fd4d4b9bd76c062596ad9d4f14b58cc1a089ab8c98cae61cf257412` — `uninitialized-local` — `src/v2/vault/DominoV2VaultExecutor.sol#L141`
  - Motivo: Falso positivo: `swapFunded` é acumulador/flag/índice cujo zero inicial é semântico em Solidity; as somas, limites ou atribuições subsequentes cobrem todos os caminhos antes de qualquer uso não nulo.
- [053] `9419f90edf859ffb3cde4c0d83257dc2358729384bd5f374d9bcb20c9a851718` — `uninitialized-local` — `src/v2/zap/DominoZapBase.sol#L130`
  - Motivo: Falso positivo: `none` é uma struct de Permit2 deliberadamente vazia, passada apenas pelas rotas BY_CALLER/BY_SIGNATURE; _act só consome permit quando by==BY_PERMIT.
- [054] `a1d78c2a6aa11d590b640c368a745f4b9e6263db33f365fb01619599db570376` — `uninitialized-local` — `src/v2/zap/DominoZapBase.sol#L94`
  - Motivo: Falso positivo: `none` é uma struct de Permit2 deliberadamente vazia, passada apenas pelas rotas BY_CALLER/BY_SIGNATURE; _act só consome permit quando by==BY_PERMIT.
- [055] `a38708bfa48c832b8170a1647a627df30274432ab4549bc7013128bf737ad162` — `uninitialized-local` — `src/v2/zap/DominoZapBase.sol#L180`
  - Motivo: Falso positivo: a struct de memória começa zerada, mas change/exit a atribuem em _withdraw (ZapBase:181-195) e create/increase a atribuem em _mint/_addLiquidity (199-207) antes dos campos retornados serem lidos.
- [056] `afdc052ede9d302519aef4208798f82fd66d2062c7f76171c31b4f7da81ec79e` — `uninitialized-local` — `src/v2/zap/DominoZapBase.sol#L116`
  - Motivo: Falso positivo: `none` é uma struct de Permit2 deliberadamente vazia, passada apenas pelas rotas BY_CALLER/BY_SIGNATURE; _act só consome permit quando by==BY_PERMIT.
- [057] `b1a0a5a2ed5f3af848c0a371051804faea54344571ffeadcf104a3eafd62360c` — `uninitialized-local` — `src/v2/fees/DominoFeeLedger.sol#L84`
  - Motivo: Falso positivo: `debited` é acumulador/flag/índice cujo zero inicial é semântico em Solidity; as somas, limites ou atribuições subsequentes cobrem todos os caminhos antes de qualquer uso não nulo.
- [058] `b7fc5f8f3490bc2dac8b35b667ca9ad5e424d8dc447ec865bd8cd044ee2b80c2` — `uninitialized-local` — `src/v2/zap/DominoZapBase.sol#L121`
  - Motivo: Falso positivo: `none` é uma struct de Permit2 deliberadamente vazia, passada apenas pelas rotas BY_CALLER/BY_SIGNATURE; _act só consome permit quando by==BY_PERMIT.
- [059] `bc30fed757631434a5a61a1ed2b0d8c46d998ed36f2f4d862261ff67773963e2` — `uninitialized-local` — `src/v2/vault/DominoV2VaultExecutor.sol#L90`
  - Motivo: Falso positivo: `swapOut` é acumulador/flag/índice cujo zero inicial é semântico em Solidity; as somas, limites ou atribuições subsequentes cobrem todos os caminhos antes de qualquer uso não nulo.
- [060] `d2b91ce4e625f5ec135aebb5c42358cf71f527b35187962b9a0791b0753f909c` — `uninitialized-local` — `src/v2/vault/DominoV2VaultExecutor.sol#L66`
  - Motivo: Falso positivo: `Run memory r` é working state zerado; rootId, pool, anchor, tarifa e arrays são preenchidos em Executor:66-93 antes dos respectivos usos.
- [061] `d5968c1800c796052e33eca2da5220530d15a42ce86fe639503ad7f35fe77dc5` — `uninitialized-local` — `src/v2/zap/DominoZapBase.sol#L81`
  - Motivo: Falso positivo: `none` é uma struct de Permit2 deliberadamente vazia, passada apenas pelas rotas BY_CALLER/BY_SIGNATURE; _act só consome permit quando by==BY_PERMIT.
- [062] `d9bec9d70586e1f275d6c7433cfee201da8cc1b419cee25de44acc178a0e27ca` — `uninitialized-local` — `src/v2/zap/DominoZapBase.sol#L302`
  - Motivo: Falso positivo: `native` é acumulador/flag/índice cujo zero inicial é semântico em Solidity; as somas, limites ou atribuições subsequentes cobrem todos os caminhos antes de qualquer uso não nulo.

### `retorno-delta-real` (11)

- [063] `1379aa888bfbb9ca072b3ca22384b48cd18dd549b4f9bd93dc77baf2fd1457f3` — `unused-return` — `src/v2/positions/DominoV3Positions.sol#L151-L178`
  - Motivo: Falso positivo: decreaseLiquidity só credita tokensOwed; collect nas linhas 173-177 fornece a entrega efetiva completa. Ignorar o retorno é a defesa intencional de contabilidade por efeito real.
- [065] `1f250f484e4e5a8ff316349dc9c915eff54ff9adfa62657d1c91432970e7eb53` — `unused-return` — `src/v2/vault/DominoV2VaultV3.sol#L109-L111`
  - Motivo: Falso positivo: _collect mede balanceOf antes/depois e credita somente o delta observado (VaultStorage:230-241). Ignorar o retorno é a defesa intencional de contabilidade por efeito real.
- [073] `607ae110c7e7bd2ab4c9c345cce03be2778d5ef56a1908576613fe0f58650c69` — `unused-return` — `src/v2/fees/DominoFeeLedger.sol#L74-L97`
  - Motivo: Falso positivo: _chargeFee mede o débito por balanceOf nas linhas 80-95 e transforma a diferença em fee devida. Ignorar o retorno é a defesa intencional de contabilidade por efeito real.
- [076] `6f31c33284cf457cb8bdfe84d11fa5aaeaf56609d4e94fbbf28892116ad19b63` — `unused-return` — `src/v2/vault/DominoV2VaultV3.sol#L137-L145`
  - Motivo: Falso positivo: executeExit mede os saldos nas linhas 374-382, em vez de confiar no Result do adaptador. Ignorar o retorno é a defesa intencional de contabilidade por efeito real.
- [079] `7608f720afd7dedc4aefd75af77b8bb4673ad5127139870b8ffbf21a00324d24` — `unused-return` — `src/v2/route/DominoSwapExecutor.sol#L390-L403`
  - Motivo: Falso positivo: o callback fecha os deltas e _executeLegs valida os saldos; o bytes de unlock não é dado contábil. Ignorar o retorno é a defesa intencional de contabilidade por efeito real.
- [082] `98f8c80fe95b19c86865fa7635f68ce941cec4dfa1a1e72292fb3289a700db04` — `unused-return` — `src/v2/vault/DominoV2VaultExecutor.sol#L212-L246`
  - Motivo: Falso positivo: a segunda anchor é deliberadamente uma asserção por revert para revalidar a banda após o swap. Ignorar o retorno é a defesa intencional de contabilidade por efeito real.
- [084] `9e8823ce029afa20f20fdb206e6244c79ea71dc2b14be35b7d3f0b1890cb0b70` — `unused-return` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Falso positivo: o hop calcula amountOut pelo saldo recebido nas linhas 379-387, inclusive para token taxado. Ignorar o retorno é a defesa intencional de contabilidade por efeito real.
- [086] `a766368f74cb0e65a5367c5488e3b28836de5fcb99f73027c07c90aec33e4f22` — `unused-return` — `src/v2/autoexit/DominoAutoExit.sol#L452-L458`
  - Motivo: Falso positivo: _push mede o débito do saldo nas linhas 452-457 e recusa débito excessivo. Ignorar o retorno é a defesa intencional de contabilidade por efeito real.
- [090] `cdecb6929a72d13e03f53f593d1c6d479f2365382b217c5d5bae9ad2ba92e19c` — `unused-return` — `src/v2/fees/DominoFeeLedger.sol#L52-L63`
  - Motivo: Falso positivo: flushOwedFees zera provisoriamente e exige delta exato de saldo nas linhas 53-62. Ignorar o retorno é a defesa intencional de contabilidade por efeito real.
- [093] `e8759295d75b88b3110952876ba820dcfdc84782c96a91fb9edc763cb2d1d32b` — `unused-return` — `src/v2/autoexit/DominoAutoExit.sol#L293-L313`
  - Motivo: Falso positivo: _withdraw mede os dois saldos antes/depois nas linhas 293-313 e aplica os mínimos ao delta real. Ignorar o retorno é a defesa intencional de contabilidade por efeito real.
- [094] `ed303b87c5fd31828a45145ea40f50d5ac270c294e2e07e8363cc155a8c9b25b` — `unused-return` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Falso positivo: o hop calcula amountOut pelo saldo recebido nas linhas 379-387, não pelo retorno assinado do pool. Ignorar o retorno é a defesa intencional de contabilidade por efeito real.

### `retorno-campo-descartado` (21)

- [064] `14405352ed2a7946a41f31ebdc16da4e045eadffe1edeb93de6ac774dc621c43` — `unused-return` — `src/v2/positions/DominoV3Positions.sol#L265-L277`
  - Motivo: Falso positivo: ticks(tickUpper) retorna oito campos; somente feeGrowthOutside0/1 são necessários; o componente usado permanece explicitamente atribuído e validado.
- [066] `242cd5d41efa93aab2fc945b47bf1c72167323127c99517f808e822cda286278` — `unused-return` — `src/v2/positions/DominoV3Positions.sol#L229-L247`
  - Motivo: Falso positivo: positions retorna nonce como primeiro campo; a leitura precisa de aprovação, pool, faixa, liquidez e checkpoints, não do nonce; o componente usado permanece explicitamente atribuído e validado.
- [067] `2b0201c296cf752c8c03d30c1057b8c3d3d3b61d3b227e75d7bb08f2937701db` — `unused-return` — `src/v2/vault/DominoV2VaultV3.sol#L52-L59`
  - Motivo: Falso positivo: o collect é apenas a varredura pré-armamento diretamente ao owner; não há valor retornado a contabilizar no vault; o componente usado permanece explicitamente atribuído e validado.
- [068] `359004f2509ca95345b457f6620c7300f2628b7c3ceef9d1645f6e3eb1edc7a8` — `unused-return` — `src/v2/zap/DominoZapV4.sol#L92-L98`
  - Motivo: Falso positivo: a leitura precisa somente de PositionInfo para extrair a faixa; a chave do pool é revalidada pelo adaptador na operação; o componente usado permanece explicitamente atribuído e validado.
- [069] `44b1d9e5ca8961d82f135b78a3e98425d952a693229446622e41ae2ecd65e360` — `unused-return` — `src/v2/positions/DominoV3Positions.sol#L265-L277`
  - Motivo: Falso positivo: ticks(tickLower) retorna oito campos; somente feeGrowthOutside0/1 são necessários; o componente usado permanece explicitamente atribuído e validado.
- [070] `4c02cb1c312618fcff7334ac8ec8921e622c6ff5f6141443ac10b6747e75184a` — `unused-return` — `src/v2/positions/DominoV4Positions.sol#L225-L233`
  - Motivo: Falso positivo: initialize retorna o tick, mas o chamador só precisa garantir a inicialização; preço/efeitos seguintes são verificados separadamente; o componente usado permanece explicitamente atribuído e validado.
- [071] `59849c2fc64db5d37ff18444e9de2fc0c2663927b5380333114554aaa7f47dc5` — `unused-return` — `src/v2/autoexit/DominoAutoExit.sol#L429-L433`
  - Motivo: Falso positivo: v4SpotAndFee valida e lê spot+fee internamente; este ponto precisa somente da fee para o piso; o componente usado permanece explicitamente atribuído e validado.
- [072] `5c1417e5d6766621b1066ee9c3529a14f8fc6f7d3eae1763a95369f6d7011e93` — `unused-return` — `src/v2/positions/DominoV3Positions.sol#L265-L277`
  - Motivo: Falso positivo: slot0 retorna sete campos; o cálculo de fee growth precisa somente do tick atual; o componente usado permanece explicitamente atribuído e validado.
- [074] `6522d4ecb2b39acbf94d41171f07d5671c54b2087ca567f1f1d583111fefcef7` — `unused-return` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Falso positivo: allowance retorna amount, expiration e nonce; após a chamada interessa somente amount==0, junto da allowance ERC-20==0; o componente usado permanece explicitamente atribuído e validado.
- [075] `6e3ab15d4d2ad3bca443b4497d30f1020182f46fd5f82e5cbf6c233f68a43a79` — `unused-return` — `src/v2/zap/DominoZapV3.sol#L57-L59`
  - Motivo: Falso positivo: o zap não precisa do endereço/preço retornado pela inicialização; a etapa seguinte valida pool e deltas; o componente usado permanece explicitamente atribuído e validado.
- [077] `72e2de8350da8fd3b933a5c43c919f4b9dec83f757002170d4339176c76e3fcf` — `unused-return` — `src/v2/autoexit/DominoAutoExit.sol#L277-L291`
  - Motivo: Falso positivo: anchor já valida spot contra a banda e aqui somente o preço-âncora é necessário; o componente usado permanece explicitamente atribuído e validado.
- [078] `7414122f59cfa28b3028f53edcda645ceb6a70d1ce11d05280a91c6a361bcb31` — `unused-return` — `src/v2/zap/DominoZapV3.sol#L52-L55`
  - Motivo: Falso positivo: a autorização usa ownerOf e esta leitura precisa apenas dos ticks da posição; o componente usado permanece explicitamente atribuído e validado.
- [080] `796e87249b79b7ea75185c4e630daa744c26f7343ab1b74d2a7c48a71e5a0472` — `unused-return` — `src/v2/vault/DominoV2VaultV3.sol#L152-L155`
  - Motivo: Falso positivo: o checkpoint v3 precisa apenas de liquidez, fee-growth e tokensOwed; os demais campos são irrelevantes; o componente usado permanece explicitamente atribuído e validado.
- [081] `7d0dc897dd153aba2c948310577902fe4f60158c6e8a197a15dc5c5fa1914cd1` — `unused-return` — `src/v2/vault/DominoV2VaultV4.sol#L101-L103`
  - Motivo: Falso positivo: v4SpotAndFee valida a leitura e somente a fee é necessária ao cálculo do piso; o componente usado permanece explicitamente atribuído e validado.
- [083] `9ad7b3d5da30244b9db83c12abbfa03b986419983fcf32ce5d01b81397652c2f` — `unused-return` — `src/v2/vault/DominoV2VaultExecutor.sol#L55-L112`
  - Motivo: Falso positivo: anchor já impõe a banda contra spot; execute precisa somente do anchor retornado; o componente usado permanece explicitamente atribuído e validado.
- [085] `9f82d08f1381fba33dd638071a01b78c7929f02a500a734746872c375b329c9a` — `unused-return` — `src/v2/anchor/DominoPriceAnchor.sol#L209-L225`
  - Motivo: Falso positivo: _spot precisa somente de sqrtPriceX96; os demais campos do StateView não entram na decisão; o componente usado permanece explicitamente atribuído e validado.
- [087] `ab8a785133af465d8c40560a7de25bb63bb69dd7a9e7552c9c01945dbdd60f6a` — `unused-return` — `src/v2/vault/DominoV2VaultV3.sol#L95-L97`
  - Motivo: Falso positivo: _liquidity precisa somente do oitavo campo positions; o componente usado permanece explicitamente atribuído e validado.
- [088] `c765867003869d261492509dc7bc4d2c9f135ce499794be0bb1efe9abaed1415` — `unused-return` — `src/v2/route/DominoSwapFloor.sol#L98-L101`
  - Motivo: Falso positivo: v3SpotAndFee precisa somente de sqrtPriceX96; a fee vem do pool separado; o componente usado permanece explicitamente atribuído e validado.
- [089] `ca326fec9925b1b3811d172f2f556f4978c12eb7b6abc1d47d91ec2ec632e357` — `unused-return` — `src/v2/positions/DominoV3Positions.sol#L291-L304`
  - Motivo: Falso positivo: _position precisa somente de token0, token1, fee e liquidity para validar identidade e retornar liquidez; o componente usado permanece explicitamente atribuído e validado.
- [091] `cf20022b70097e51b1b76b2d3cfe2cc3f9001e5d45970f8f12cc5ecd871c2090` — `unused-return` — `src/v2/zap/DominoZapV4.sol#L100-L102`
  - Motivo: Falso positivo: o zap só requer que a inicialização conclua; o retorno é informativo e a operação subsequente valida o pool; o componente usado permanece explicitamente atribuído e validado.
- [092] `e6c8decc0e231c67a8e7c70acce2433d887e8de4b1e5d64dc1d463bb5fb80a0f` — `unused-return` — `src/v2/positions/DominoV3Positions.sol#L214-L223`
  - Motivo: Falso positivo: initialize lê somente currentSqrtPriceX96 de slot0; os outros seis campos não são usados; o componente usado permanece explicitamente atribuído e validado.

### `zero-owner-factory` (1)

- [096] `45b4de94d4cd401003075095d0f0120ae2d3e5ee5a1b2157d5c40a2499e2f6c0` — `missing-zero-check` — `src/v2/vault/DominoV2VaultBase.sol#L146`
  - Motivo: Falso positivo: initialize é factory-only e o factory passa `msg.sender` como owner (Factory:40-53); uma transação EVM nunca tem msg.sender zero. Logo owner_ não pode ser zero neste fluxo.

### `zero-governance-intencional` (1)

- [097] `727fed175006248ecb51d50e9c9b669e731c55db88e718563940a0b8c9090678` — `missing-zero-check` — `src/v2/registry/DominoRegistry.sol#L180`
  - Motivo: Falso positivo: zero é valor suportado para retirar uma transferência de governança pendente, documentado no próprio método (Registry:178-183); acceptGovernance exige msg.sender==pending e zero nunca chama.

### `zero-implementation-indireto` (1)

- [098] `a71962dc5ce19c8acf39cdef6ef66690441b41962061b4c935e26f36f307f7cc` — `missing-zero-check` — `src/v2/vault/DominoV2VaultFactory.sol#L22`
  - Motivo: Falso positivo: antes de armazenar implementation, o construtor chama wiring() e root() e exige wiring.factory==address(this) e DEX válido (Factory:22-30). address(0), EOA ou contrato incompatível reverte antes da atribuição.

### `arm-reentrancia` (2)

- [188] `9e0045517dbcd0b32ed40a734d9a81ed8dc7acacf83739d395cfbed8946dd4dc` — `reentrancy-benign` — `src/v2/vault/DominoV2VaultV3.sol#L52-L59`
  - Motivo: Falso positivo: `_arm` é alcançado durante initialize (factory-only, `_initialized`/owner/pool já gravados) ou por rearm protegido pela trava; a coleta v3 paga diretamente ao owner e `_record` deve capturar o checkpoint final. Tokens hostis não passam onlyOwner/operador, e as demais mutações usam a trava transitória compartilhada.
- [192] `5a610a23a005a0cf18f885bd18abffde397c7ce2b0c9a09e4cd43e7639f69fe7` — `reentrancy-events` — `src/v2/vault/DominoV2VaultV3.sol#L52-L59`
  - Motivo: Falso positivo: `_arm` é alcançado durante initialize (factory-only, `_initialized`/owner/pool já gravados) ou por rearm protegido pela trava; a coleta v3 paga diretamente ao owner e `_record` deve capturar o checkpoint final. Tokens hostis não passam onlyOwner/operador, e as demais mutações usam a trava transitória compartilhada.

### `factory-evento` (1)

- [191] `481f9949c299354bb01ed62add458326da6805ca730a2e54462dec89fd1c8704` — `reentrancy-events` — `src/v2/vault/DominoV2VaultFactory.sol#L40-L54`
  - Motivo: Falso positivo: o factory incrementa nonce e registra isVault antes de initialize (Factory:40-52); uma criação aninhada pelo próprio owner só pode usar o nonce seguinte. O evento após initialize descreve o clone concluído e não protege estado nem autorização.

### `timestamp-falso-parser` (1)

- [196] `3c403dcd2fb923c2d0ed8f2e3b22d5dd80b7cc860f80d6a9c89d2f0af08891d3` — `timestamp` — `src/v2/positions/DominoV3Positions.sol#L325-L327`
  - Motivo: Falso positivo inequívoco: `_minimum` compara somente `liquidity < minLiquidity` (DominoV3Positions:325-327); não lê block.timestamp nem qualquer valor temporal.

### `estado-nao-usado-arquitetura` (16)

- [313] `03140a10df0464248c7ba2762182863d89e7bde800d319f3d44c9c7b5257a77a` — `unused-state` — `src/v2/vault/DominoV2VaultStorage.sol#L63`
  - Motivo: Falso positivo de visão por concrete contract/DEX: o símbolo pertence ao layout/base comum e é consumido pelo par implementation/executor via delegatecall ou somente pela variante v3/v4 pertinente. Preservá-lo mantém layout e razões de disarm compartilhados; não é estado morto no sistema implantado.
- [314] `07399b58cc849ccdbad41f0c8daeaa1a3a2745edc66a88e11fc250087411a835` — `unused-state` — `src/v2/vault/DominoV2VaultStorage.sol#L63`
  - Motivo: Falso positivo de visão por concrete contract/DEX: o símbolo pertence ao layout/base comum e é consumido pelo par implementation/executor via delegatecall ou somente pela variante v3/v4 pertinente. Preservá-lo mantém layout e razões de disarm compartilhados; não é estado morto no sistema implantado.
- [315] `125ef903cd27e7b1dfcefab2dcd994ee17ebda5ddbd8e8e5c146030e97f5bd98` — `unused-state` — `src/v2/vault/DominoV2VaultStorage.sol#L64`
  - Motivo: Falso positivo de visão por concrete contract/DEX: o símbolo pertence ao layout/base comum e é consumido pelo par implementation/executor via delegatecall ou somente pela variante v3/v4 pertinente. Preservá-lo mantém layout e razões de disarm compartilhados; não é estado morto no sistema implantado.
- [316] `1390c35cc8973f2f7b23bf70c063baeb89de9856d0cd4a9a731ae5807e7e7808` — `unused-state` — `src/v2/vault/DominoV2VaultStorage.sol#L60`
  - Motivo: Falso positivo de visão por concrete contract/DEX: o símbolo pertence ao layout/base comum e é consumido pelo par implementation/executor via delegatecall ou somente pela variante v3/v4 pertinente. Preservá-lo mantém layout e razões de disarm compartilhados; não é estado morto no sistema implantado.
- [317] `16f62a97d5e9b379f0b385a79e632aaf29d65486ed1d79c6ba798beae466e034` — `unused-state` — `src/v2/vault/DominoV2VaultStorage.sol#L59`
  - Motivo: Falso positivo de visão por concrete contract/DEX: o símbolo pertence ao layout/base comum e é consumido pelo par implementation/executor via delegatecall ou somente pela variante v3/v4 pertinente. Preservá-lo mantém layout e razões de disarm compartilhados; não é estado morto no sistema implantado.
- [318] `2da78df6c4b14693309c1defe5e224947fd3759b912be0f9aa78557b42c1b540` — `unused-state` — `src/v2/vault/DominoV2VaultStorage.sol#L62`
  - Motivo: Falso positivo de visão por concrete contract/DEX: o símbolo pertence ao layout/base comum e é consumido pelo par implementation/executor via delegatecall ou somente pela variante v3/v4 pertinente. Preservá-lo mantém layout e razões de disarm compartilhados; não é estado morto no sistema implantado.
- [319] `5d0d6e7be2dccab1549173aa67e39f06a8712854ad756438519c6303e5226560` — `unused-state` — `src/v2/vault/DominoV2VaultStorage.sol#L59`
  - Motivo: Falso positivo de visão por concrete contract/DEX: o símbolo pertence ao layout/base comum e é consumido pelo par implementation/executor via delegatecall ou somente pela variante v3/v4 pertinente. Preservá-lo mantém layout e razões de disarm compartilhados; não é estado morto no sistema implantado.
- [320] `66d99db259248c28977ac76ff7d367835b2e11f27dfdbbbbd7dbde4e1f53247c` — `unused-state` — `src/v2/vault/DominoV2VaultStorage.sol#L58`
  - Motivo: Falso positivo de visão por concrete contract/DEX: o símbolo pertence ao layout/base comum e é consumido pelo par implementation/executor via delegatecall ou somente pela variante v3/v4 pertinente. Preservá-lo mantém layout e razões de disarm compartilhados; não é estado morto no sistema implantado.
- [321] `70e6e6f8942dc1fd29639f7ecaf16dc06384672fb5e496448a5be5f35b23a77d` — `unused-state` — `src/v2/vault/DominoV2VaultStorage.sol#L60`
  - Motivo: Falso positivo de visão por concrete contract/DEX: o símbolo pertence ao layout/base comum e é consumido pelo par implementation/executor via delegatecall ou somente pela variante v3/v4 pertinente. Preservá-lo mantém layout e razões de disarm compartilhados; não é estado morto no sistema implantado.
- [322] `8676436ed37d54b6bdda2bb20f16867dc24586bcb4989e823f2785a71e4ca2d3` — `unused-state` — `src/v2/vault/DominoV2VaultStorage.sol#L59`
  - Motivo: Falso positivo de visão por concrete contract/DEX: o símbolo pertence ao layout/base comum e é consumido pelo par implementation/executor via delegatecall ou somente pela variante v3/v4 pertinente. Preservá-lo mantém layout e razões de disarm compartilhados; não é estado morto no sistema implantado.
- [323] `86ef628c15b629ce2f43a4bc5355a09c6190a649bec235dd06de3f12fc23f85f` — `unused-state` — `src/v2/vault/DominoV2VaultStorage.sol#L112`
  - Motivo: Falso positivo de visão por concrete contract/DEX: o símbolo pertence ao layout/base comum e é consumido pelo par implementation/executor via delegatecall ou somente pela variante v3/v4 pertinente. Preservá-lo mantém layout e razões de disarm compartilhados; não é estado morto no sistema implantado.
- [324] `94a42f873de33fa1bd235d3c43d6acabe1d35782645b2e48fd8ffab550f14d35` — `unused-state` — `src/v2/vault/DominoV2VaultStorage.sol#L58`
  - Motivo: Falso positivo de visão por concrete contract/DEX: o símbolo pertence ao layout/base comum e é consumido pelo par implementation/executor via delegatecall ou somente pela variante v3/v4 pertinente. Preservá-lo mantém layout e razões de disarm compartilhados; não é estado morto no sistema implantado.
- [325] `b8aac10e5524ba9f2ce9df4fabd83b1f6617bf0d64c72ac1643b405959b161b9` — `unused-state` — `src/v2/vault/DominoV2VaultStorage.sol#L60`
  - Motivo: Falso positivo de visão por concrete contract/DEX: o símbolo pertence ao layout/base comum e é consumido pelo par implementation/executor via delegatecall ou somente pela variante v3/v4 pertinente. Preservá-lo mantém layout e razões de disarm compartilhados; não é estado morto no sistema implantado.
- [326] `d6e897afc53e9a73136ca769c7a2fe51c1031d273fa24c23dddd82dc4f254244` — `unused-state` — `src/v2/vault/DominoV2VaultStorage.sol#L112`
  - Motivo: Falso positivo de visão por concrete contract/DEX: o símbolo pertence ao layout/base comum e é consumido pelo par implementation/executor via delegatecall ou somente pela variante v3/v4 pertinente. Preservá-lo mantém layout e razões de disarm compartilhados; não é estado morto no sistema implantado.
- [327] `ecd5a55a3988ef6da177848ce7ecb6d630f2ebe61090783bd4fc126f2996b28c` — `unused-state` — `src/v2/vault/DominoV2VaultStorage.sol#L64`
  - Motivo: Falso positivo de visão por concrete contract/DEX: o símbolo pertence ao layout/base comum e é consumido pelo par implementation/executor via delegatecall ou somente pela variante v3/v4 pertinente. Preservá-lo mantém layout e razões de disarm compartilhados; não é estado morto no sistema implantado.
- [328] `fc15aa3eeb24ae68391ef356070cc280398339f90764b9375322908cff8bcc6f` — `unused-state` — `src/v2/vault/DominoV2VaultStorage.sol#L58`
  - Motivo: Falso positivo de visão por concrete contract/DEX: o símbolo pertence ao layout/base comum e é consumido pelo par implementation/executor via delegatecall ou somente pela variante v3/v4 pertinente. Preservá-lo mantém layout e razões de disarm compartilhados; não é estado morto no sistema implantado.

### `constable-delegatecall` (22)

- [330] `032bcaa73c6c375f200cf4e584f20e66ededde570bdc66e3bdda6f439f0aa5e2` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L82`
  - Motivo: Falso positivo de análise por contrato: `_paused` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultBase.sol:171,194-207,314. Torná-lo constant quebraria a configuração/contabilidade por vault.
- [331] `0c2d5944e52b9ff5aa1fbddf01a1ac8e0a2a262a571a5d900bf62e3452a4be30` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L110`
  - Motivo: Falso positivo de análise por contrato: `_exitModule` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultBase.sol:315-318,346-351. Torná-lo constant quebraria a configuração/contabilidade por vault.
- [332] `0f2071ce52d4e98ad558e6b4d4d7593ba781d1c7a2a29c38ea3eeea6f59440dc` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L106`
  - Motivo: Falso positivo de análise por contrato: `_currency1` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultBase.sol:155-161. Torná-lo constant quebraria a configuração/contabilidade por vault.
- [333] `10bd68b372cb83f8a442020be0838e4d6280c8e8fa01dd02dd70eb07622af5b4` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L94`
  - Motivo: Falso positivo de análise por contrato: `_maxSlippageBps` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultBase.sol:405-415. Torná-lo constant quebraria a configuração/contabilidade por vault.
- [334] `195262d2492609b53173f9cfd272144c14c15bf29b1380a8613dbd1375049871` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L112`
  - Motivo: Falso positivo de análise por contrato: `_rootCheckpoint` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultV3.sol:151-163. Torná-lo constant quebraria a configuração/contabilidade por vault.
- [335] `1c41f87765c183714c8bb4da5779e7d8ec140799381294ac8d05c0281398c997` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L95`
  - Motivo: Falso positivo de análise por contrato: `_maxPriceImpactBps` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultBase.sol:405-415. Torná-lo constant quebraria a configuração/contabilidade por vault.
- [336] `1eeb69261f3eaf752a26b50e61c9a1316356887dbf39a0f6ee0677a2caa1de3a` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L90`
  - Motivo: Falso positivo de análise por contrato: `_triggerDistanceBps` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultBase.sol:391-403. Torná-lo constant quebraria a configuração/contabilidade por vault.
- [337] `22af3cb9ee6eacee8ff90484c732f0788d70365c54ecf60900ae49db7f5926e7` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L98`
  - Motivo: Falso positivo de análise por contrato: `_lastExecutionAt` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultExecutor.sol:62-63,107-108. Torná-lo constant quebraria a configuração/contabilidade por vault.
- [338] `235fce5f15bd9c606ac973ef936fc6572f9984f79be64c6e42034c040aed8973` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L104`
  - Motivo: Falso positivo de análise por contrato: `_fee` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultBase.sol:155-161. Torná-lo constant quebraria a configuração/contabilidade por vault.
- [339] `35e22fa299815814016a34c24fd4fdd825631b330d527bb6018111f3d786df73` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L103`
  - Motivo: Falso positivo de análise por contrato: `_currency0` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultBase.sol:155-161. Torná-lo constant quebraria a configuração/contabilidade por vault.
- [340] `3dad94f4809906c606a13efc358530f751724e43cb68008360456cde0c508b85` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L89`
  - Motivo: Falso positivo de análise por contrato: `_mode` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultBase.sol:391-403. Torná-lo constant quebraria a configuração/contabilidade por vault.
- [341] `49e7e8672e6d77fabe3eda822f1d583f124f49e1d36a3afe8e0d17da19199a6e` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L93`
  - Motivo: Falso positivo de análise por contrato: `_maxPositions` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultBase.sol:391-403. Torná-lo constant quebraria a configuração/contabilidade por vault.
- [342] `756ec394093466a2a4ea6771383700c88256b98a186afc50900c62c26ec9e9fb` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L108`
  - Motivo: Falso positivo de análise por contrato: `_rootTokenId` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultBase.sol:148-163. Torná-lo constant quebraria a configuração/contabilidade por vault.
- [343] `77ec28eab738e44fb468b03722c5e662acbeb9cb98b96726e0527fca3a01e83d` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L92`
  - Motivo: Falso positivo de análise por contrato: `_minimumIntervalSeconds` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultBase.sol:391-403. Torná-lo constant quebraria a configuração/contabilidade por vault.
- [344] `8f407973c55bd53985ee772349ffd82b2de19a6857d81a07f3a4b7f338105952` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L86`
  - Motivo: Falso positivo de análise por contrato: `_inverse` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultBase.sol:164-169. Torná-lo constant quebraria a configuração/contabilidade por vault.
- [345] `9b5f52d76f6669a3307e41b13df2c2ba69c133ca2ba46f811e0c71b50dfad686` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L91`
  - Motivo: Falso positivo de análise por contrato: `_maxOverlapBps` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultBase.sol:391-403. Torná-lo constant quebraria a configuração/contabilidade por vault.
- [346] `9e58bcf4d26b38e99d4b0b01f6a4d7428667d9e746913f0c4879a50740c7448b` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L80`
  - Motivo: Falso positivo de análise por contrato: `_owner` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultBase.sol:146-175 (atribuição na linha 154). Torná-lo constant quebraria a configuração/contabilidade por vault.
- [347] `a2aba9f62ddbc86746abab58758804b4b763579588ae38799786dd4c93ca939e` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L97`
  - Motivo: Falso positivo de análise por contrato: `_upsideBps` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultBase.sol:405-415. Torná-lo constant quebraria a configuração/contabilidade por vault.
- [348] `b33f3e0236190c55d31bee3cc4722522cfd5dd6418bd3d5029a9d1a0c98a3330` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L105`
  - Motivo: Falso positivo de análise por contrato: `_tickSpacing` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultBase.sol:155-161. Torná-lo constant quebraria a configuração/contabilidade por vault.
- [349] `bf5ab6fc007e388ad7bfe4dfb8def5f152ce3ca444e972e8c2c6a357384ba3dc` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L96`
  - Motivo: Falso positivo de análise por contrato: `_maxObservationAgeSeconds` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultBase.sol:405-415. Torná-lo constant quebraria a configuração/contabilidade por vault.
- [350] `f07f0cdf11fd7c24b5c818d32f038fd3def3daaefd91b8815e6bbd36a86dea27` — `constable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L107`
  - Motivo: Falso positivo de análise por contrato: `_hooks` não é constante; clones escrevem o layout comum via implementation/executor delegado. Escritas: DominoV2VaultBase.sol:155-161. Torná-lo constant quebraria a configuração/contabilidade por vault.
- [351] `282b4dc85c0228974f0109781caba2c1832edcb2a86136d6bd0ef72df372ff75` — `immutable-states` — `src/v2/vault/DominoV2VaultStorage.sol#L87`
  - Motivo: Falso positivo: `_initialized` precisa morar no storage de cada clone para impedir segunda inicialização; o implementation/executor marca seu próprio storage no construtor e cada clone o marca em initialize (Storage:119-133; Base:146-154). Immutable não funciona por clone via EIP-1167.


## Aceitos ou informacionais

### `shadow-abi` (1)

- [095] `9ac3ef9d16ac4c0d6ac3d8a50ae49c9fe0b15ed85c3b2ece7143862ff81e5884` — `shadowing-local` — `src/v2/external/IUniswapV3Minimal.sol#L128`
  - Motivo: Informacional: `liquidity` é nome de um componente da tupla ABI de positions, enquanto `liquidity()` é outro selector da interface do pool; não há variável de storage sombreada nem ambiguidade de dispatch.

### `loop-leg-8` (60)

- [099] `0a11e8710674b5d6c209dde2baeac9eb92d1c1a66e3b35779011f17ef25927b4` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [100] `147a611c7ef956b0d1c208e63e799a75e2d9e241023874ff56e3be8062df847a` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [102] `1a5a79ff0dae0c097dfb8c39a9e439a61ba0815f35152bfd4715cd15ebdad7f9` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [103] `1d30bba4e4a02bb442ee20767de0419aaa4975fa3dcf4e0421b687d668c034a2` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [104] `1d91b2a276be818d9457bbaf619a3862238832ff46f7ccc1fb5ef58a7e9ed685` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L390-L403`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [105] `258f6afcc2f7ad27be8f6893d55b165b36102970321906f060017e0d80f08414` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L390-L403`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [108] `284bc5538d78dd4c64eb716fc824c57df1f5a692d08cbb86a61bfcb07af66623` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [109] `285ba20ed4f47fbb3f77a0d799472f44b27f3f647c4e7c0b388d0c509b0049c7` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [110] `30525ccf8f36c87381c2a4d20388c0f3c680fdfed0fbd352cc37d71e981c6fcd` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [111] `30704b6285e3f6a5e8e0e02297be5f33bda1830ed04a0473c98fbaa8d8f8afbf` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [112] `334d68a44524c2a0fb03c4571d1437299c02b710d6ac07868bac22aa6e11f12d` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [113] `364ce6c7ddd7943d569e35542eb1e9df819f7608d5a2f7366c818b21cd1e5697` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [114] `3a6f6eb8824f4958c3632c028f916de4bc99bd8fddf989650ca04d7d8717cad3` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [115] `3b75e48c0be920bbe9facc221baacfb5508282363cc14b3c67483624fe36f530` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [116] `3c32fadd402f8a070d579aee1e49fc53fa1ac13947eeab67bbecc5987c49ae05` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [117] `3dca93e4e92adaae4518b821fcc54f5de9687cc166a419de0cd09f1ae1be965a` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [121] `4abee4625a160bc2d3c12e398a6bc26fdae7f17409f06128bd3491db0132a2db` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L390-L403`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [122] `4ae6faf2e310862a5fe197c75a4313f58a629418543a960b55e5e5b4126f78e3` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [124] `545a99ad8a4c06cf5d75876e59d770d31e9d8b6f2ffc788e3ac42ca993cde3d1` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [125] `580b0905cd725907e908fd4eefe0cd910969f2c3019be11d0a560e9855de922f` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [130] `6624cc012c9e1d3261c804cd8bf94c3fedb784933257365edf30518ee604dc13` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [131] `66a0cb92fe0201e55ee14238bf1912152afa97b66ab2d53cb391520f9f8b720c` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L390-L403`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [134] `6ce662b6d71f9f1607bd0ac8233bdf136d1acdc128aa946d0e34f277f54209bb` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [135] `6d2a090110815314f4b0fcd725a6d0ea2684902a2435f6a3fa6dbd8aaa74d1b6` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [136] `6f822711d3eb41747bbd0e482bfe0fb259d564f8a1f9ab7eea8fe12923313831` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [137] `72b34d595d111f4f1ca207997d0a362b5e90b45a9885b0d5fe2e36c5b3b54d82` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L390-L403`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [138] `73c8c44511683861bea6a18ba40dc39313387e2d66adebdd8558371a60f9672d` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [139] `73dd006a9fa372f412538befdf40b98e9ca75476ea89cee904679304e9698af2` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [140] `7760c5752bd32d298c9bf256be5a07809ceefc04f3b47de1f08ac3c1c60d3e84` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L390-L403`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [141] `7a1e0e27b35a8efe5aa0b6588cc0a3e784b5f6322e7ca7f9d9c40ab5d0ac71f0` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L390-L403`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [142] `7e439695c35b1852196085ca431bcafa2a7a8424d3c4e401ee6acb3de7444298` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [144] `86ca40507a0e562ac3407714f047d57d2b8216f715791fec93cec9076d51c23a` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L390-L403`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [145] `88342b7179209d88eaa744851228ce01b112c204ec4730ca6cb01b2c83777d5f` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [146] `884d74461320c3887ef646ebfbd10d578523706cdba783cf8d38c80c189297ea` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [147] `892db58bfd792d25e13a36e68aee8cda309f397af379983476d9a6addded76e6` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [148] `896b7b1d9ddf252a7c3bb3a29780d3c7815918fbd64ac5ee110a5e7b6a34aa7d` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [149] `8a8c733aba39f4c171c1039871473c7c30f69d0e739284d04bce30a63362c788` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [150] `8db7c2574cf20917078aeab6b0a5bf1d61055a6651eb5413bcd4ad45c6391e55` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [151] `92372c329d53ae5f0a0c55e7c55841784a7d1e1a361d30746f5ba91839571a12` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [153] `954d441d999caae9e7781d7ed8330492dce342e30f209642fb5649680316ce88` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [155] `9d91ccc45fb9b27540242466a7822306a4b3fda4254f25ad39f79462774d558e` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [156] `9db8132ba4ec5ec72ffb2aabbfe21db5e58473718cbf33e3261526e5f0446a5d` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [157] `9e54754e1ddc8d7e2db853c27913409dfc9ac8369ebfdc4b1209f09dfe4f3c86` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [158] `a54cf3f97421842e3432639d4fc7471ec8370313a8827e54b0c62be234e27368` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [159] `a701e42a8061181c47b2f8304e2eaa88ca47aec7719899029f06f1df9ffc1a25` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [164] `c256b69de006a3fc42ba2c1d767adc7c39604fce06328e187bbd1bdd752c610d` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [165] `c4b90f6ffef9f7a7fdf8ad60a2b98e94ceaf299fda164b4dc31ad5affda4b966` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [166] `c7e914df21d84560601971c4bb8121f6304f4cbca4d80d327d78eaa3fb3892f8` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [167] `cd08e963af50ec65fe1a2ebd05d199011bacb7f85dcbd0c596ef6b6011715f80` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L390-L403`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [168] `d2bbbde161a5742978309bf8dd8d0b7d1c4b4196ece27d2b00e366a8439972f6` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L390-L403`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [170] `d8eaeba25c9cda70af62c326fe53acc09ccf1636e10a0747a71b897398728693` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [172] `df2b356a4ac9045a58432cbd11a4253765cbf31c986d752eca0eb404f8358281` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [173] `e3463dc60004e533227717152e572eb7286f64af41beed0b29e153d6d72579d5` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [175] `e715a1e9e731b8bdfbf311759c9d83d6a7fa0d59e599eb6babb529fd6e4534b3` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [178] `e9eb43cb3cdcd26b7c386ea854a76b7c148e19ec2e858fce79e1df4a044391df` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [179] `eb404a7c74c441e228dd4a91f07c42ddc2bfbfb7961fc65adcd514c4fc80be41` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [181] `f58f8541b23d857add8ec56d075172ae229ff24b3bd61d0854bdde11e0f7439f` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [182] `fb4024a5eaf530a16f79916ee6da30b442984588fb42af2095c27c7ca2b95c00` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [183] `fcc7e3ef64732b2d03fdc91cb15c1bc17648c79b2a88f97534c567b5f5b03b33` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.
- [184] `ff9357e78e2d651e8e33364d9bdbc11bc7b9ee1773ff8c8ffb0a4934c15075d0` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: a chamada está no loop de `_executeLegs`, cujo comprimento é recusado acima de MAX_LEGS=8 (SwapExecutor:75,133-154); cada iteração é intencional, atômica e seguida de validação de todos os saldos rastreados.

### `loop-hop-4` (24)

- [101] `1a4e649d02b9e78e69a5a56cb992bab59fc65a44ef14655f517d00cec45e0abe` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [107] `27764805537360d3a5551dab70f1d01abe78ffa0175c16f0da5b5bc705c920a2` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [118] `43432d3c35e533b393bb4186508c9c4fad99c264e632c76fce85af967d738986` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [119] `484a0b2f8f2af6027b87c3e940f50bd00879a0f037e330cf1d12bed107982b6b` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [120] `48fd104318d564f2f8c76fa76ecdbabdbfd12969ef59ab3a8b2cd1114c262f69` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L230-L256`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [123] `503bc49ab1bc99e188dad4da05b655942d68e2d7f04d3d5d29d445981533b143` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [126] `59d4032a841f89fda50affffeb08b6522f43b763b9bbd07c3319ebb09ed7356f` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [127] `5df6f22a72df31dd22fbcef9e70a8f3f5d419875ebf0eb3de29ef36144905ccf` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [128] `5e5d5949b5320f860002364bb7b8f714f6ccf99b8325ea1f1bce71a60523148f` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [129] `60e2c357ab49f53e0ea366bc12ff360da4fa3eaca46c771b5b5d08014d1e35d9` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [132] `6abb865ae1f568eff65350d5c7251eaae988691b476267391ae8de39ff70e585` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [133] `6bc9ded8950e07ea1b0447c4ac6f846421366c252dfdb4b1c3fc87af9b0ee187` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [143] `82863f486c43f7808271a838ae4116f8d56c2399cc6a91fc4e3d73f1673122d9` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [152] `92b3b27d3de22eaabad66cee06eeecd5daa7463f00e3417bce474ee2f4dca0a4` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L230-L256`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [154] `9a66097315ffb0b1971a9df4c9639cb6280ff9a009c92d288f0b42193a6b2a57` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L230-L256`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [160] `a8029043a51932e38e710f258e9156260614962bd11ab99a581c5b548296f6f0` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [161] `a9c14ba858eb97e9dd08cc7525299acecffd837b5caae09928d691e1ced088c7` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [162] `af0e9fcb3f32647c383a069645e3306f37321a392046f06bf8b3a3c9f2732c7e` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [163] `c0cef2cbd487bbef1056a2205f8c7bebdfd35bc19d5ab846565f57d519556ac8` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L230-L256`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [171] `da8df9a9f51b26cd16c8d914db98a340b4e60a6cee403c658d8a6d587ff47ad3` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [174] `e5dfbf2e9e9912fa26b7aab0f9b473454a9a9833cedd13f993e9e9d50eb834b2` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [176] `e8ebf7dcda1bda61ed4d69057bed988188e03c7e0315169f7cb68116074ed9cb` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [177] `e9980b8f1d053a1211f0f9f78c920b6d55d26697c500a93a735889a9348d4811` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.
- [180] `edbe737ae6f23f28ca83e27892f93ce62799df36715a4c2120bb12a92647520b` — `calls-loop` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: a chamada está no path de pools, explicitamente limitado a MAX_HOPS=4 (SwapExecutor:75-76,230-256,326-350), dentro de no máximo oito legs; falha reverte toda a ação e os efeitos ainda são conferidos por saldo.

### `loop-exitall-aceito` (2)

- [106] `267ad1e44779ed6fc392bb94032d08853f0ae849258d4ceafa69883a5169a007` — `calls-loop` — `src/v2/vault/DominoV2VaultStorage.sol#L277-L279`
  - Motivo: Risco de disponibilidade aceito: exitAll itera filhos e faz transferFrom, mas a quantidade é limitada por `_maxPositions` uint8 e cada falha reverte atomicamente. O pacote §7 registra crescimento de gás e saída filho a filho como fallback.
- [261] `2b6748dea1ef644edb57d3ae62839c7668b5eaf8bb0d6c5fa5465a78dcc25299` — `costly-loop` — `src/v2/vault/DominoV2VaultStorage.sol#L246-L261`
  - Motivo: Risco de disponibilidade aceito: `_retire` faz busca/remoção no array durante exitAll; membros são limitados por uint8, o pacote §7 documenta o crescimento de gás e permite withdrawChild um a um se exitAll não couber.

### `loop-collect-bounded` (1)

- [169] `d489f71fbbebc24c9074aeda0d4de6cfc5011f89bcf6964fb78e40ba1026c112` — `calls-loop` — `src/v2/vault/DominoV2VaultV4.sol#L159-L169`
  - Motivo: Informacional: o unlock aparece no loop de collect, porém `_validate` exige tokenIds estritamente crescentes e ativos; a lista não excede os membros do vault, limitados por `_maxPositions` uint8. O operador escolhe um plano que caiba em gás e revert é atômico.

### `timestamp-intencional` (8)

- [195] `0e71e8c4b60306c7217fc7b7c85bd7bd0778b89a78a0d77068e5b56c2675b968` — `timestamp` — `src/v2/anchor/DominoPriceAnchor.sol#L170-L186`
  - Motivo: Informacional: `_verify` usa tempo para deadline, validade/frescor, epoch, timelock ou intervalo mínimo — exatamente a regra temporal do protocolo. Pequena variação de timestamp do bloco não contorna autorização, assinatura, banda ou limites.
- [197] `6da7a3493e3684e97fac7bf496a48e42f0b9fc7fe6ec6a52bf1d46f502259946` — `timestamp` — `src/v2/registry/DominoRegistry.sol#L242-L246`
  - Motivo: Informacional: `raiseObservationEpoch` usa tempo para deadline, validade/frescor, epoch, timelock ou intervalo mínimo — exatamente a regra temporal do protocolo. Pequena variação de timestamp do bloco não contorna autorização, assinatura, banda ou limites.
- [198] `74f4fd8d8da85fec68d0e6329d6cec5d5e259d776b089d8bbb79df714d8ce19f` — `timestamp` — `src/v2/registry/DominoRegistry.sol#L204-L211`
  - Motivo: Informacional: `executeChange` usa tempo para deadline, validade/frescor, epoch, timelock ou intervalo mínimo — exatamente a regra temporal do protocolo. Pequena variação de timestamp do bloco não contorna autorização, assinatura, banda ou limites.
- [199] `802b775503c5ac40872e511f25b6d342248a141c7a2e82ea21b9e672124849d1` — `timestamp` — `src/v2/zap/DominoZapBase.sol#L248-L259`
  - Motivo: Informacional: `_open` usa tempo para deadline, validade/frescor, epoch, timelock ou intervalo mínimo — exatamente a regra temporal do protocolo. Pequena variação de timestamp do bloco não contorna autorização, assinatura, banda ou limites.
- [200] `9495a3771ec8d8dc0651b8f126ab76412258ddeae9ac6258a033a480b3d804a3` — `timestamp` — `src/v2/registry/DominoRegistry.sol#L265-L267`
  - Motivo: Informacional: `_readmit` usa tempo para deadline, validade/frescor, epoch, timelock ou intervalo mínimo — exatamente a regra temporal do protocolo. Pequena variação de timestamp do bloco não contorna autorização, assinatura, banda ou limites.
- [201] `d28b6065737b3980611069c03b1e7120de95d9c7e6c26a87e65fa30cdf6b491c` — `timestamp` — `src/v2/autoexit/DominoAutoExit.sol#L235-L271`
  - Motivo: Informacional: `_authorize` usa tempo para deadline, validade/frescor, epoch, timelock ou intervalo mínimo — exatamente a regra temporal do protocolo. Pequena variação de timestamp do bloco não contorna autorização, assinatura, banda ou limites.
- [202] `ec2c10bd4fe1e014f2f6ceebda70527846c8af9e75730fa41459063e615ba789` — `timestamp` — `src/v2/autoexit/DominoAutoExit.sol#L203-L219`
  - Motivo: Informacional: `_checkTerms` usa tempo para deadline, validade/frescor, epoch, timelock ou intervalo mínimo — exatamente a regra temporal do protocolo. Pequena variação de timestamp do bloco não contorna autorização, assinatura, banda ou limites.
- [203] `f68e9ac205d0c09ff4becf41010903f6f91c353260e7f2239fe3e0dbfb5f0a9b` — `timestamp` — `src/v2/vault/DominoV2VaultExecutor.sol#L55-L112`
  - Motivo: Informacional: `execute` usa tempo para deadline, validade/frescor, epoch, timelock ou intervalo mínimo — exatamente a regra temporal do protocolo. Pequena variação de timestamp do bloco não contorna autorização, assinatura, banda ou limites.

### `assembly-domino` (35)

- [204] `019723939b828442d677ef3e7f2bc736e85ea149579a9d3fbe9ababe8191f035` — `assembly` — `src/v2/vault/DominoV2VaultV4.sol#L159-L169`
  - Motivo: Informacional: o bloco em `_unlocked` marca e limpa o unlock transitório ao redor da chamada ao PoolManager; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [205] `06527dca354e436904076934d43b6f4661e037c87dea07728f0afdce43f0c361` — `assembly` — `src/v2/route/DominoSwapExecutor.sol#L297-L324`
  - Motivo: Informacional: o bloco em `_checkRouterCommands` lê selector, offset, tamanho e comandos depois das checagens explícitas de limites; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [206] `06e0dcdade686002a7b280eae3b926ef46d3bf9ec66c46963d3409a0bfe40bbb` — `assembly` — `src/v2/route/DominoSwapExecutor.sol#L166-L184`
  - Motivo: Informacional: o bloco em `uniswapV3SwapCallback` lê e limpa o contexto transitório autenticado do pool e do pagamento; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [208] `1380d73d894160df2137313464a0f06af37aabc0a340142b9de74feb169477ef` — `assembly` — `src/v2/route/DominoSwapExecutor.sol#L390-L403`
  - Motivo: Informacional: o bloco em `_swapV4` grava o hash transitório do callback esperado; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [209] `185bfad6e1d484bb83736555a1d75fafff9651fec1e4e23d992486923a086830` — `assembly` — `src/v2/zap/DominoZapBase.sol#L367-L385`
  - Motivo: Informacional: o bloco em `_actionTokens` encurta in-memory o array já alocado para a cardinalidade deduplicada; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [212] `23394e856e68f5341002d7db244522fc0fce6d8673eaaa7a11c3b1bec2b22da1` — `assembly` — `src/v2/route/DominoTokenOps.sol#L57-L75`
  - Motivo: Informacional: o bloco em `tryTransfer` faz chamada de token com gás e cópia de retorno limitados; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [213] `3111c18b4a3f0383d3beead209bb1ecbae7cc90be7458c979dc3f10080067188` — `assembly` — `src/v2/route/DominoSwapExecutor.sol#L326-L350`
  - Motivo: Informacional: o bloco em `_swapV3` decodifica o path compacto v3 após validar seu comprimento; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [214] `35f7420c3c5097448a14e70d49a921720749ec697813f1fa6377d5b65ba63ad7` — `assembly` — `src/v2/zap/DominoZapV4.sol#L62-L82`
  - Motivo: Informacional: o bloco em `unlockCallback` lê hash transitório e/ou propaga revert bruto do callback autenticado; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [215] `367a6d5668a2a0d3aec763d27a809d2d3a3a42710e3d58b0d4203b8b556d5303` — `assembly` — `src/v2/vault/DominoV2VaultStorage.sol#L304-L309`
  - Motivo: Informacional: o bloco em `_unlocking` lê a flag transitória de unlock; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [220] `4c61e91e1fe4a3e991062075d40bcce1f3cab09c20384f1751d0be6a65199486` — `assembly` — `src/v2/route/DominoTokenOps.sol#L78-L91`
  - Motivo: Informacional: o bloco em `approve` faz approve com retorno limitado e valida contrato/booleano; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [221] `5999fb8adc510ef54a6b71ad996356d77b6e95750aa743aea5b7d907b71c9f4c` — `assembly` — `src/v2/autoexit/DominoAutoExit.sol#L464-L468`
  - Motivo: Informacional: o bloco em `_setExiting` grava a flag transitória que admite native durante a saída; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [222] `5e602b8ec1ac1a75ad6f44018d4f6be66fda92b6260011a0cab2dc0e762635d1` — `assembly` — `src/v2/anchor/DominoPriceAnchor.sol#L190-L202`
  - Motivo: Informacional: o bloco em `_recover` extrai r/s/v após validar assinatura de 65 bytes; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [223] `5e6413a55831dde661ea7023708e736dedbccf74b22aa4cd9f0a1ce6a06a1821` — `assembly` — `src/v2/route/DominoSwapExecutor.sol#L425-L442`
  - Motivo: Informacional: o bloco em `_trackedTokens` encurta in-memory o conjunto deduplicado de tokens rastreados; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [224] `614c792a896897f4e6e5dd2204c2299ba2dd421e4dccd2abe7123886092395cf` — `assembly` — `src/v2/anchor/AnchorMath.sol#L65-L71`
  - Motivo: Informacional: o bloco em `_mul512` calcula o produto 512-bit por mul/mulmod; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [225] `64a4a183aca77f2341c4253b7ee8c56599655abe56198f9cab25c385b37e28fe` — `assembly` — `src/v2/autoexit/DominoAutoExit.sol#L470-L474`
  - Motivo: Informacional: o bloco em `_exiting` lê a flag transitória que admite native durante a saída; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [226] `6ceb20037c87f88460a4eeae101454496d11b2517259021fa6d273a58a88c1c5` — `assembly` — `src/v2/zap/DominoZapBase.sol#L263-L295`
  - Motivo: Informacional: o bloco em `_verifyRelayed` extrai r/s/v de assinatura de exatamente 65 bytes; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [231] `7f90df90180ee6dc3c896cfa702631ac4a5cd813f2df06f1da7e8c5594aeda1e` — `assembly` — `src/v2/route/DominoSwapExecutor.sol#L193-L197`
  - Motivo: Informacional: o bloco em `_v4LegPending` lê o hash transitório de callback v4; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [234] `8c99248d74752e6e941ff8b37eb7913e258b5af591bedf47d8a632b0873f5331` — `assembly` — `src/v2/vault/DominoV2VaultStorage.sol#L288-L294`
  - Motivo: Informacional: o bloco em `_rootStep` grava a flag transitória de alteração da raiz; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [235] `8e13b57ecf71723c74f6d172257f786383cd4e858507c10160d6ebea8237ca15` — `assembly` — `src/v2/vault/DominoV2VaultV4.sol#L71-L86`
  - Motivo: Informacional: o bloco em `_arm` marca e limpa a janela transitória de subscribe; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [238] `a799a0d221e5902caebd54bfeada4df0d4ff86e3556888a7f52711140509f032` — `assembly` — `src/v2/route/DominoActionLock.sol#L26-L30`
  - Motivo: Informacional: o bloco em `_actionLocked` lê a trava transitória compartilhada; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [239] `b0109de7893c99e48e5aab5e49e0caccb7f4c5b71163ed78e16214c686b57eb9` — `assembly` — `src/v2/route/DominoSwapExecutor.sol#L459-L463`
  - Motivo: Informacional: o bloco em `_setSwapping` grava a flag transitória de swap; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [240] `b0dcf5a7295e3b259cb1d2366e6c7d48f1bcce7ed6250b1b049c911adace0c7c` — `assembly` — `src/v2/vault/DominoV2VaultFactory.sol#L40-L54`
  - Motivo: Informacional: o bloco em `createVault` executa CREATE2 com o bytecode EIP-1167 calculado; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [241] `b1cf3e30a7d2931f83ffc89cfb1611fd14348d47e0a942105c33e4a08e195d96` — `assembly` — `src/v2/zap/DominoZapBase.sol#L347-L361`
  - Motivo: Informacional: o bloco em `_transferIn` faz transferFrom com retorno limitado e valida contrato/booleano; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [242] `b1fa1218cd5803c61dd324911ccde064a40d97aad374b4c2b496790dbbc2ea89` — `assembly` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: o bloco em `_callRouter` propaga o revert bruto de router já admitido; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [243] `b2ddbea809da706f93a056873d11167f0b7aafb874c93c1e2d3cfa5060495c60` — `assembly` — `src/v2/vault/DominoV2VaultV4.sol#L231-L238`
  - Motivo: Informacional: o bloco em `notifySubscribe` lê a janela transitória de subscribe; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [244] `b6ee18aa9f1794878d48d284f5d173586a826949daef4d4d8952be88ab04e5cb` — `assembly` — `src/v2/route/DominoSwapExecutor.sol#L157-L161`
  - Motivo: Informacional: o bloco em `_swapInProgress` lê a flag transitória de swap; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [249] `c77bc0de6090e0e6421d91804fb113f4d966b2d4f49cd9668f7d8092f5a4d978` — `assembly` — `src/v2/route/DominoSwapExecutor.sol#L199-L224`
  - Motivo: Informacional: o bloco em `_v4LegCallback` lê e limpa o hash transitório autenticado; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [250] `cb8f8a0819c39c01fc433086fd67c0545f654f19843c763faaa38f4150f1e8e4` — `assembly` — `src/v2/route/DominoSwapExecutor.sol#L352-L388`
  - Motivo: Informacional: o bloco em `_swapV3Hop` grava pool/token/amount transitórios do callback autenticado; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [251] `d0e23d47a5da73fbd6f63d704b8132eff7345170948f9fb7df2bac6bef8c7a5f` — `assembly` — `src/v2/vault/DominoV2VaultStorage.sol#L296-L301`
  - Motivo: Informacional: o bloco em `_inRootStep` lê a flag transitória de alteração da raiz; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [252] `dcc5e7ed395ce0419cf430062de5f5f5268b200621165130fb0583eece019447` — `assembly` — `src/v2/fees/DominoFeeLedger.sol#L117-L121`
  - Motivo: Informacional: o bloco em `_feeStorage` aponta a struct ao slot ERC-7201 namespaced; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [255] `e50e69eeb75cc1b70e8eefde5bf05fdb16c71b9b3f9ef1bc0345524644f9d3f6` — `assembly` — `src/v2/route/DominoTokenOps.sol#L36-L48`
  - Motivo: Informacional: o bloco em `allowance` faz staticcall com retorno limitado a uma palavra; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [257] `e71650da448d163592a06d964807cc1f9c947cb49d8e779a18b1158ac0554724` — `assembly` — `src/v2/route/DominoTokenOps.sol#L18-L29`
  - Motivo: Informacional: o bloco em `balanceOf` faz staticcall com retorno limitado a uma palavra; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [258] `f723bd77334630ceb27305f99f9d4c208df737f586dac8775a2c0ac674721328` — `assembly` — `src/v2/vault/DominoV2VaultBase.sol#L381-L387`
  - Motivo: Informacional: o bloco em `_delegate` propaga retorno/revert bruto do executor imutável; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [259] `fb9a5b98ca3ccf2cf75295f3754aeb88ff9bba6075d0faa68aaae7471602e797` — `assembly` — `src/v2/vault/DominoV2VaultExecutor.sol#L212-L246`
  - Motivo: Informacional: o bloco em `_swap` propaga revert bruto do módulo imutável de swap; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.
- [260] `fc199b4f7d01d158fe2660d69b635f5c34acb96301dbb3c199d53893b9c0a2b4` — `assembly` — `src/v2/zap/DominoZapV4.sol#L146-L153`
  - Motivo: Informacional: o bloco em `_run` grava o hash transitório do unlock esperado; as precondições e a autenticação estão nas linhas adjacentes, e a mera presença de assembly não demonstra falha.

### `assembly-vendor` (22)

- [207] `11c527589bf1cc9707fd5e2b94e8585492f580ea4471378e2c6426eaab8cf107` — `assembly` — `src/v2/positions/uniswap/CustomRevert.sol#L31-L37`
  - Motivo: Informacional: assembly de `revertWith` implementa codificação ABI de erros terminais no arquivo upstream `CustomRevert`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [210] `1e1d0662ec65a3c650a543524cac02d84546dada436c1d74f87c1cf1ad9ee0d7` — `assembly` — `src/v2/positions/uniswap/SqrtPriceMath.sol#L129-L149`
  - Motivo: Informacional: assembly de `getNextSqrtPriceFromInput` implementa aritmética e checagens de preço no arquivo upstream `SqrtPriceMath`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [211] `20efaddb7b173f31ecefb2c19b579665aeea25b52b5982d28608624532317e7c` — `assembly` — `src/v2/positions/uniswap/FullMath.sol#L14-L102`
  - Motivo: Informacional: assembly de `mulDiv` implementa aritmética 512-bit e divisão modular no arquivo upstream `FullMath`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [216] `39bb9212198530b66fab01a794afe488d7ad01415262e9b03d55855f65d699a8` — `assembly` — `src/v2/positions/uniswap/CustomRevert.sol#L40-L46`
  - Motivo: Informacional: assembly de `revertWith` implementa codificação ABI de erros terminais no arquivo upstream `CustomRevert`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [217] `3a0ea379fd7e3fba35cf060f445fbb80c76960ca8486991b65de1ff23587696b` — `assembly` — `src/v2/positions/uniswap/CustomRevert.sol#L22-L28`
  - Motivo: Informacional: assembly de `revertWith` implementa codificação ABI de erros terminais no arquivo upstream `CustomRevert`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [218] `46a1511620e4403b125c6cf51d4ef735355d89aff6b2105996057ddf4a36ba79` — `assembly` — `src/v2/positions/uniswap/SqrtPriceMath.sol#L188-L211`
  - Motivo: Informacional: assembly de `getAmount0Delta` implementa aritmética e checagens de preço no arquivo upstream `SqrtPriceMath`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [219] `4ab936320bcd5d974b815380944e69062c0f38a95b81c7d64ce5c08751fea4e3` — `assembly` — `src/v2/positions/uniswap/UnsafeMath.sol#L24-L28`
  - Motivo: Informacional: assembly de `simpleMulDiv` implementa divisão aritmética mínima no arquivo upstream `UnsafeMath`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [227] `70a6669b42820f667268f53c84bc04de95ef882546bfc73bc0a78f71de8c3282` — `assembly` — `src/v2/positions/uniswap/SqrtPriceMath.sol#L86-L120`
  - Motivo: Informacional: assembly de `getNextSqrtPriceFromAmount1RoundingDown` implementa aritmética e checagens de preço no arquivo upstream `SqrtPriceMath`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [228] `73291451f484c8e4d0874dac1188ecec4f0b2b34e7018bb0e451f055c429eb89` — `assembly` — `src/v2/positions/uniswap/TickMath.sol#L121-L237`
  - Motivo: Informacional: assembly de `getTickAtSqrtPrice` implementa conversão tick/preço em ponto fixo no arquivo upstream `TickMath`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [229] `7595158af2c985965dbb797e6062b6016a556d0c834b930444b1016b2bee0daf` — `assembly` — `src/v2/positions/uniswap/CustomRevert.sol#L49-L57`
  - Motivo: Informacional: assembly de `revertWith` implementa codificação ABI de erros terminais no arquivo upstream `CustomRevert`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [230] `7c62a7fd62c40992a0b0620af95d257c701f289cc0e5ce14885dedf61a0ed8be` — `assembly` — `src/v2/positions/uniswap/UnsafeMath.sol#L12-L16`
  - Motivo: Informacional: assembly de `divRoundingUp` implementa divisão aritmética mínima no arquivo upstream `UnsafeMath`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [232] `88a50e17fab31c52f7660d1230bfde403f3a9cb962672916fb48302132e9d9cf` — `assembly` — `src/v2/positions/uniswap/BitMath.sol#L31-L48`
  - Motivo: Informacional: assembly de `leastSignificantBit` implementa tabelas de busca de bits no arquivo upstream `BitMath`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [233] `8bd8901f0357f080bbf62884637cb61ed278aa712ee8143a5cbc2171200ec41c` — `assembly` — `src/v2/positions/uniswap/BitMath.sol#L12-L25`
  - Motivo: Informacional: assembly de `mostSignificantBit` implementa tabelas de busca de bits no arquivo upstream `BitMath`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [236] `961e6822f912306ff1dde02e1fba7e94d6ee0bebeb1cee2327aa810656a469fa` — `assembly` — `src/v2/positions/uniswap/SqrtPriceMath.sol#L214-L225`
  - Motivo: Informacional: assembly de `absDiff` implementa aritmética e checagens de preço no arquivo upstream `SqrtPriceMath`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [237] `9a423a38b180c5e2630c82673223c3346ab5b74fadce325ef928be8cd477ff76` — `assembly` — `src/v2/positions/uniswap/SqrtPriceMath.sol#L234-L254`
  - Motivo: Informacional: assembly de `getAmount1Delta` implementa aritmética e checagens de preço no arquivo upstream `SqrtPriceMath`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [245] `b7187e81d84d0e63422dd64264ddb4b118c828112576b1639aadafc10e92639c` — `assembly` — `src/v2/positions/uniswap/CustomRevert.sol#L71-L79`
  - Motivo: Informacional: assembly de `revertWith` implementa codificação ABI de erros terminais no arquivo upstream `CustomRevert`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [246] `ba08f0231f86b5806a5834ad6a84f7519946f62c35aa5b59343ef2ec1939294c` — `assembly` — `src/v2/positions/uniswap/TickMath.sol#L57-L114`
  - Motivo: Informacional: assembly de `getSqrtPriceAtTick` implementa conversão tick/preço em ponto fixo no arquivo upstream `TickMath`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [247] `ba6c6ccbe7b1a373c5cf24d17dbe4e7a91998174749a5153d2477e719aa660af` — `assembly` — `src/v2/positions/uniswap/CustomRevert.sol#L14-L19`
  - Motivo: Informacional: assembly de `revertWith` implementa codificação ABI de erros terminais no arquivo upstream `CustomRevert`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [248] `c44b212f31ef69d534bf1f191bf8948e359eeddaa948e96358510f83a174164d` — `assembly` — `src/v2/positions/uniswap/SqrtPriceMath.sol#L31-L74`
  - Motivo: Informacional: assembly de `getNextSqrtPriceFromAmount0RoundingUp` implementa aritmética e checagens de preço no arquivo upstream `SqrtPriceMath`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [253] `e2070d7cf49f01dd214b4d1f8c4bf72b349164926c414c1d51d1d729246f8622` — `assembly` — `src/v2/positions/uniswap/SqrtPriceMath.sol#L158-L178`
  - Motivo: Informacional: assembly de `getNextSqrtPriceFromOutput` implementa aritmética e checagens de preço no arquivo upstream `SqrtPriceMath`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [254] `e327074dbf6281e380cb7b748499350ca02943acfb99788d7577aa7e1220fc89` — `assembly` — `src/v2/positions/uniswap/CustomRevert.sol#L83-L119`
  - Motivo: Informacional: assembly de `bubbleUpAndRevertWith` implementa codificação ABI de erros terminais no arquivo upstream `CustomRevert`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.
- [256] `e6c59752e18705d6f7160946ab5cb197c7190ddbc3b58364243242a7c62c51e2` — `assembly` — `src/v2/positions/uniswap/CustomRevert.sol#L60-L68`
  - Motivo: Informacional: assembly de `revertWith` implementa codificação ABI de erros terminais no arquivo upstream `CustomRevert`; a comparação independente confirmou igualdade com a referência oficial após apenas pragma/imports permitidos.

### `complexidade` (5)

- [262] `26183cd2ffd334ce7befc767cbc5e0da02a36a03e186f36c0ba03b5eb8102205` — `cyclomatic-complexity` — `src/v2/zap/DominoZapBase.sol#L151-L215`
  - Motivo: Informacional: `_act` tem complexidade ciclomática elevada conforme contado pelo scanner. A complexidade vem de branches de validação explícitos; não é evidência de caminho incorreto por si.
- [263] `9ff4afbe8c404d50740913b66c57cb03ed4682628ab27fa58a843305e14d0cfd` — `cyclomatic-complexity` — `src/v2/positions/uniswap/TickMath.sol#L57-L114`
  - Motivo: Informacional: `getSqrtPriceAtTick` tem complexidade ciclomática elevada conforme contado pelo scanner. É implementação upstream vendorizada.
- [264] `a8594c64bba6bac0ba6e0af0dd32ab6afd8ff84685e392d566389288aea8bc0f` — `cyclomatic-complexity` — `src/v2/vault/DominoV2VaultExecutor.sol#L115-L156`
  - Motivo: Informacional: `_validate` tem complexidade ciclomática elevada conforme contado pelo scanner. A complexidade vem de branches de validação explícitos; não é evidência de caminho incorreto por si.
- [265] `d3df088a864b11623d8ba4d143f4edc61a16f83e8748d1a36f5f03e0dd849b67` — `cyclomatic-complexity` — `src/v2/vault/DominoV2VaultExecutor.sol#L55-L112`
  - Motivo: Informacional: `execute` tem complexidade ciclomática elevada conforme contado pelo scanner. A complexidade vem de branches de validação explícitos; não é evidência de caminho incorreto por si.
- [266] `e5543b96ca4d1edbd733b2d5b1fbebe4ccd28c1745efef39a25ffc6a11644c35` — `cyclomatic-complexity` — `src/v2/registry/DominoRegistry.sol#L269-L319`
  - Motivo: Informacional: `_apply` tem complexidade ciclomática elevada conforme contado pelo scanner. A complexidade vem de branches de validação explícitos; não é evidência de caminho incorreto por si.

### `dead-code` (1)

- [267] `6b7b25d19558dfbdbb6ceee43c8594c4f9f68d96d4fc400516565b53ff1f9672` — `dead-code` — `src/v2/fees/DominoFeeLedger.sol#L104-L106`
  - Motivo: Informacional confirmado: `_feeRegistry()` não tem uso neste tree; é helper morto sem reachability externa, sem efeito de segurança ou runtime além de tamanho de código potencial.

### `low-level` (11)

- [268] `189c12879b594902b85ba1dd8b253d67f05c6b5e08d96b1b8bec39e3b27145e7` — `low-level-calls` — `src/v2/zap/DominoZapV4.sol#L62-L82`
  - Motivo: Informacional: delegatecall tem alvo STEPS imutável e payload preso ao hash pendente do unlock; falha é propagada.
- [269] `32359358f6c909ba4ef789b366d03c007954c74687e2f3e66e7fe49bb65b01f2` — `low-level-calls` — `src/v2/vault/DominoV2VaultExecutor.sol#L212-L246`
  - Motivo: Informacional: delegatecall usa SWAP_MODULE imutável com code.length, ABI fixa, trava ativa e validação externa dos deltas de saldo.
- [270] `3855df55875ebe866bd1520303f314c88bf71271c898c2625e376187e03a6393` — `low-level-calls` — `src/v2/route/DominoSwapExecutor.sol#L270-L292`
  - Motivo: Informacional: call alcança somente router timelock-admitido, comandos allowlisted, allowance exata/zerada e efeito integral conferido por saldo.
- [271] `5522283b5827709e38cdf2a7f234988177aaa7870f2be03911d5400ce182ac62` — `low-level-calls` — `src/v2/vault/DominoV2VaultV3.sol#L201-L208`
  - Motivo: Informacional: staticcall de positions trata revert esperado e decodifica somente em sucesso para decidir root fechada.
- [272] `5fed4eaf1bbe0596f1fe2bbc7e2800a498262c9c9477ad743afb5b52f850eddf` — `low-level-calls` — `src/v2/anchor/DominoPriceAnchor.sol#L227-L238`
  - Motivo: Informacional: staticcall do pool CREATE2 canônico converte qualquer falha/retorno vazio em TwapUnavailable antes de decodificar.
- [273] `6c3f518d4e8972e52d998ce466dacb31d6c5e0ddf3d3ae6392b58f0aee92932e` — `low-level-calls` — `src/v2/positions/DominoV4Positions.sol#L377-L389`
  - Motivo: Informacional: call ERC-20 aceita retorno vazio/booleano, depois settleFor exige exatamente o pagamento esperado.
- [274] `6d27dd2ac2bffb1b507d3186c5df2cf016b0000fb1028f7771964a0fa58717fa` — `low-level-calls` — `src/v2/vault/DominoV2VaultBase.sol#L381-L387`
  - Motivo: Informacional: delegatecall é o dispatcher proxy para EXECUTOR/SWAP_MODULE imutáveis e propaga retorno ou revert bruto.
- [275] `8399fcf5a570dfcffc13c1765a633037921a7d194004dd991fee962cb52d9fb7` — `low-level-calls` — `src/v2/positions/DominoV3Positions.sol#L314-L317`
  - Motivo: Informacional: call approve valida sucesso e, quando presente, o bool retornado.
- [276] `900d00cde274ce232691e2e6f361a5a154b86fd80d1091e36a5dfbdb84240431` — `low-level-calls` — `src/v2/anchor/DominoPriceAnchor.sol#L209-L225`
  - Motivo: Informacional: staticcall slot0 valida sucesso e tamanho ABI mínimo de 224 bytes antes do decode.
- [277] `9b33eaa4a1cfc362263006f23776aa9f2d7cd8da87f1ccd7dd5b48bc4c46d9fe` — `low-level-calls` — `src/v2/autoexit/DominoAutoExit.sol#L223-L231`
  - Motivo: Informacional: staticcall EIP-1271 valida sucesso, tamanho mínimo e magic value.
- [278] `a6b6fa6b3e99e258f3cf6bbfa12ff2a4be6e08515fac09da9f659f232c7d2d98` — `low-level-calls` — `src/v2/vault/DominoV2VaultStorage.sol#L223-L228`
  - Motivo: Informacional: staticcall ownerOf trata falha como não aprovado; resposta malformada reverte de forma segura.

### `missing-inheritance` (2)

- [279] `0be9e07f083454d585cd1e0f8fd09fcbf855c11c4f524db6ccfc21ef993fcdac` — `missing-inheritance` — `src/v2/vault/DominoV2VaultV4.sol#L221-L268`
  - Motivo: Informacional: `DominoV2VaultV4` expõe o selector e a assinatura esperados sem declarar a interface sugerida; herança nominal não altera ABI/runtime nem a autenticação do callback neste caso.
- [280] `a8c566c205787baa379aca61a2fb915ae0f603ed1951d6e2f0453762d5cfd297` — `missing-inheritance` — `src/v2/vault/DominoV2VaultV4.sol#L200-L211`
  - Motivo: Informacional: `DominoV2VaultExecutorV4` expõe o selector e a assinatura esperados sem declarar a interface sugerida; herança nominal não altera ABI/runtime nem a autenticação do callback neste caso.

### `naming` (27)

- [281] `117af699a43a7e35fa723b8bd17a2afa622ec0bcf92ebbcfa236f714fb199c0a` — `naming-convention` — `src/v2/zap/DominoZapV3.sol#L24`
  - Motivo: Informacional de estilo: o nome apontado em `WRAPPED_NATIVE` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [282] `12eb92fc59acc3fa747a65bbf6ab898f3114e30665f37cd39ec0caf63a0df6d4` — `naming-convention` — `src/v2/vault/DominoV2VaultV4.sol#L52`
  - Motivo: Informacional de estilo: o nome apontado em `POOL_MANAGER` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [283] `25fc4e80779c58edb29191a0ce43d40ce3f0e48c7d419b71ca3965cea78ae4dd` — `naming-convention` — `src/v2/vault/DominoV2VaultStorage.sol#L74`
  - Motivo: Informacional de estilo: o nome apontado em `PRICE_ANCHOR` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [284] `3438b9c1999832c76f66a066418d8a4b6dc3492a1b38b2e4c598290d20513d6e` — `naming-convention` — `src/v2/interfaces/IDominoAutoExitExtension.sol#L65`
  - Motivo: Informacional de estilo: o nome apontado em `MAX_SLIPPAGE_BPS` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [285] `3aabe47fab92610f74618d4be2323d83ea3add7b5f41c7bef46a2eea9beb78ec` — `naming-convention` — `src/v2/vault/DominoV2VaultStorage.sol#L76`
  - Motivo: Informacional de estilo: o nome apontado em `SWAP_MODULE` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [286] `3b34ced93dcd76b3caf32a9168a783ea7dcdfa44b53c29c7d5acf0edb497f7c2` — `naming-convention` — `src/v2/vault/DominoV2VaultStorage.sol#L71`
  - Motivo: Informacional de estilo: o nome apontado em `DEX` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [287] `3c7d7e9d1175b13023a3e852b41596bfd065ddf632c7d1fedd68375334b25ef9` — `naming-convention` — `src/v2/zap/DominoZapV4.sol#L34`
  - Motivo: Informacional de estilo: o nome apontado em `STEPS` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [288] `431ea0dbecd208066810950545d98855d3f5ca713a4b67003044eba0987e5a80` — `naming-convention` — `src/v2/vault/DominoV2VaultStorage.sol#L73`
  - Motivo: Informacional de estilo: o nome apontado em `REGISTRY` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [289] `4608ff917fb36ff056dee6d49a1f811d0b63deab71988643e232022b8c26d915` — `naming-convention` — `src/v2/vault/DominoV2VaultStorage.sol#L75`
  - Motivo: Informacional de estilo: o nome apontado em `POSITION_MANAGER` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [290] `490e5d4c711ebf3b286628150bb94e039f845fa20dbdd8407b8767d585c8f8b0` — `naming-convention` — `src/v2/interfaces/IDominoAutoExitExtension.sol#L76`
  - Motivo: Informacional de estilo: o nome apontado em `MAX_TWAP_SECONDS` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [291] `4b56426a0fc4af470cdf9fcbb9579cfc4f6f34e9c8b4357f2464eca5924c9f30` — `naming-convention` — `src/v2/fees/DominoFeeLedger.sol#L37`
  - Motivo: Informacional de estilo: o nome apontado em `FEE_REGISTRY` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [292] `64c58ab5f4a6e75f802a5027e87bed5924e02c84f511f26508a848dadeba68da` — `naming-convention` — `src/v2/route/DominoSwapExecutor.sol#L108`
  - Motivo: Informacional de estilo: o nome apontado em `ROUTE_REGISTRY` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [293] `694123d34f8356ccff11c31b519099c1f280b0cb72e4cc120e77d0e2550768ef` — `naming-convention` — `src/v2/interfaces/IDominoAutoExitExtension.sol#L67`
  - Motivo: Informacional de estilo: o nome apontado em `MAX_POOL_FEE_PIPS` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [294] `6a26f231017bc8c23f99fcb9358a01b54d5b79b9fafe8c2b0b4c0fa1a8263f1c` — `naming-convention` — `src/v2/zap/DominoZapV3.sol#L23`
  - Motivo: Informacional de estilo: o nome apontado em `POSITION_MANAGER` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [295] `6c2cd36feac6cfa9a6ddbca6b31c5ef7ce75cd57d9e2ad8c3e5e8bca63b06c54` — `naming-convention` — `src/v2/zap/DominoZapV4Steps.sol#L37`
  - Motivo: Informacional de estilo: o nome apontado em `SELF` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [296] `842cacba73c68644de1469e3c1f70594020c2520636dee09f43303e21bfe1d87` — `naming-convention` — `src/v2/vault/DominoV2VaultBase.sol#L38`
  - Motivo: Informacional de estilo: o nome apontado em `EXECUTOR` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [297] `877469889f03658fecb48f5626b9b85ba487ed45f524033bcd4754402ad5791e` — `naming-convention` — `src/v2/vault/DominoV2VaultStorage.sol#L77`
  - Motivo: Informacional de estilo: o nome apontado em `AUTO_EXIT` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [298] `965b8d0d82471536355bc6a957a6e5b0d34d159efa12b0b87cf168c757cf0498` — `naming-convention` — `src/v2/route/DominoSwapExecutor.sol#L112`
  - Motivo: Informacional de estilo: o nome apontado em `V4_POOL_MANAGER` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [299] `98af0340818605c3d2a7530cceed89d04ed713e2496d90b3f99861bb1ff5136b` — `naming-convention` — `src/v2/vault/DominoV2VaultStorage.sol#L72`
  - Motivo: Informacional de estilo: o nome apontado em `FACTORY` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [300] `a8a4518e6fde755bb9659efe45a6e8a0d653b93fa9f88194f5fcb36db107ab27` — `naming-convention` — `src/v2/route/DominoSwapExecutor.sol#L110`
  - Motivo: Informacional de estilo: o nome apontado em `V3_FACTORY` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [301] `bb27a900b5a0df2c5c27af81f6e2670b22a18f17d432c13fa0d299c99ab4a4a7` — `naming-convention` — `src/v2/route/DominoSwapExecutor.sol#L111`
  - Motivo: Informacional de estilo: o nome apontado em `V3_POOL_INIT_CODE_HASH` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [302] `bc660abc47ad5b8ac67fcf8281c59a4cbd88d41e1007d42172b35234837f0a2d` — `naming-convention` — `src/v2/zap/DominoZapV4.sol#L33`
  - Motivo: Informacional de estilo: o nome apontado em `POSITION_MANAGER` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [303] `be920f4d16a80f79b8a3779cc5377b4ebde3fd5c450cdb8c1cc66981a66e38a9` — `naming-convention` — `src/v2/interfaces/IDominoAutoExitExtension.sol#L69`
  - Motivo: Informacional de estilo: o nome apontado em `INSTRUCTION_VERSION` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [304] `cb384f51dc0c53e612ec809e3aa814634d5e359b87923aa7b34cce0661361bde` — `naming-convention` — `src/v2/route/DominoSwapExecutor.sol#L109`
  - Motivo: Informacional de estilo: o nome apontado em `PERMIT2` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [305] `d6c14a234148c93abc9031fdbdeebe5d9340fb7549d756ed0d4c19bcf5e878d7` — `naming-convention` — `src/v2/vault/DominoV2VaultV3.sol#L30`
  - Motivo: Informacional de estilo: o nome apontado em `V3_FACTORY` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [306] `eb8f2cc959ccaad099ebf07ff40cdb0b63df3106dcb8f4f88a8f509ab081d047` — `naming-convention` — `src/v2/vault/DominoV2VaultExecutor.sol#L30`
  - Motivo: Informacional de estilo: o nome apontado em `SELF` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.
- [307] `ebfff029b6856e507a1b89a8dac76d80004e6ac941013b1b4bf112ff06c482f2` — `naming-convention` — `src/v2/external/IUniswapV3Minimal.sol#L89`
  - Motivo: Informacional de estilo: o nome apontado em `WETH9` segue a convenção local de imutáveis/constantes em maiúsculas ou uma ABI externa congelada; não altera selector além do que a interface exige nem cria falha.

### `digits` (5)

- [308] `302d3bae9738d0ad35ca6cadf2944235e127fe9afd52d843c6c96d31c9b5b21e` — `too-many-digits` — `src/v2/positions/uniswap/CustomRevert.sol#L83-L119`
  - Motivo: Informacional de legibilidade: o literal em `bubbleUpAndRevertWith` é máscara/constante de ponto fixo vendorizada; separar dígitos poderia melhorar leitura, mas não muda semântica nem precisão.
- [309] `5fd39e9702e33d27880bc77e63c977f4631fa388b8a1a5236410e455cdd19128` — `too-many-digits` — `src/v2/positions/uniswap/FixedPoint128.sol#L6-L8`
  - Motivo: Informacional de legibilidade: o literal em `slitherConstructorConstantVariables` é máscara/constante de ponto fixo vendorizada; separar dígitos poderia melhorar leitura, mas não muda semântica nem precisão.
- [310] `71ba5cee3091c2fb6e40b09cb81fd7568c77807ae51f1bb33784a247116fe559` — `too-many-digits` — `src/v2/positions/uniswap/CustomRevert.sol#L83-L119`
  - Motivo: Informacional de legibilidade: o literal em `bubbleUpAndRevertWith` é máscara/constante de ponto fixo vendorizada; separar dígitos poderia melhorar leitura, mas não muda semântica nem precisão.
- [311] `87dd22f3bbc3e24f8026717dfbdc75b1c0c085c51424876c392862e5f87dd85b` — `too-many-digits` — `src/v2/positions/uniswap/BitMath.sol#L12-L25`
  - Motivo: Informacional de legibilidade: o literal em `mostSignificantBit` é máscara/constante de ponto fixo vendorizada; separar dígitos poderia melhorar leitura, mas não muda semântica nem precisão.
- [312] `a833167097315f95ac72312bcac97024c136e2c38d219092a3aa147af4e916a5` — `too-many-digits` — `src/v2/positions/uniswap/FixedPoint96.sol#L7-L10`
  - Motivo: Informacional de legibilidade: o literal em `slitherConstructorConstantVariables` é máscara/constante de ponto fixo vendorizada; separar dígitos poderia melhorar leitura, mas não muda semântica nem precisão.

### `unused-op-withdraw` (1)

- [329] `fe0ac43ebe38bf30b2ec3423e1ab9c20a51c935291f1f5f3c3cd4b6532d5300c` — `unused-state` — `src/v2/zap/DominoZapV4Steps.sol#L19`
  - Motivo: Informacional confirmado: `OP_WITHDRAW` não é comparado nominalmente porque, após OP_MINT e OP_INCREASE, o ramo final executa withdraw; dados chegam somente do caller com hash pendente e `_run` usa op=3. É constante simbólica redundante, não operação externamente selecionável.


## Não verificados

Nenhum.
## Validação programática e preservação

- `triage.json` contém uma entrada por índice/ID, a descrição original, classificação, motivo em PT-BR e linhas do scanner/evidência adicional.
- Validações: índices exatamente 0..351; IDs únicos e cobertura multiconjunto idêntica à entrada; contagens por detector idênticas; toda referência de linha existe e está dentro do arquivo.
- Fonte antes: commit `5e63d2dba9123fdc585f7f272b83532b491fbc51`, tree `db8bfb4e57a043a94f7fe55bf02725cb65836b1c`, status limpo.
- Fonte depois: commit `5e63d2dba9123fdc585f7f272b83532b491fbc51`, tree `db8bfb4e57a043a94f7fe55bf02725cb65836b1c`, status limpo.
- Nenhuma suite original foi executada, nenhum worker foi lançado e nenhum arquivo da fonte canônica foi alterado.

## Artefatos

- JSON: `[USER_HOME]/.hermes/cache/scratch/domino-v2-audit-20261004/evidence/slither-triage/triage.json`
- Relatório: `[USER_HOME]/.hermes/cache/scratch/domino-v2-audit-20261004/evidence/slither-triage/report.md`
- Evidência do probe: `[USER_HOME]/.hermes/cache/scratch/domino-v2-audit-20261004/evidence/slither-triage/probe-results.json`
