# Evidências da auditoria defensiva Domino V2

Comece por AUDITORIA_DOMINO_V2.md e FINDINGS.json. O veredito consolidado prevalece sobre classificações limitadas de ferramentas.

Este arquivo contém evidências, não um snapshot de fonte completo. Recupere o commit/árvore exatos do repositório indicado no freeze para reconstruir. O arquivo tracked-sha256.json identifica os bytes originais. Dependências node_modules/venv não são transportadas; inventários e hashes das lockfiles estão em environment.json.

Os logs registram os diretórios originais para proveniência; não representam caminhos portáveis. checks/results.json lista comandos e cwd realmente usados. Para reproduzir a matriz, use npm ci na raiz e app, o build explícito do pacote, o build separado test/v2/integration/IntegrationArtifacts.sol e os artefatos V1 exigidos pelo wrapper; execute cada suíte original listada em checks/expected-suites.json separadamente. O cold-instructions registra o roteiro original incompleto, preservado como falha e não como teste aprovado.

O arquivo slither/receipt.json registra os fontes/settings; triage.json mapeia cada ID do scanner. A classificação do scanner não certifica o produto.

O resultado de mutações é uma amostra selecionada, não replay das campanhas históricas. Restored verdict NOT CAUGHT significa que a suíte original restaurada passou — não um mutante sobrevivente.

Material operacional de exploração e raciocínio interno de workers não fazem parte da entrega. Nenhum token, chave ou credencial é necessário para ler este pacote. O relatório explicita o único skip opcional nos helpers V1.

Verifique cada membro contra MANIFEST.json; o hash do próprio zip é externo para evitar circularidade.
